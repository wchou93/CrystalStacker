# -*- coding: utf-8 -*-
"""2D layer-stacking engine for layered COFs and related 2D materials.

The engine converts a **single-layer** structure (read from a CIF) into the
stacking configurations of Figure 2 of the reference study:

==============  ===========================================================
mode            construction
==============  ===========================================================
``inclined``    the *c* vector is tilted by the in-plane offset; the
                **fractional** atomic coordinates are carried over unchanged,
                so the atom count is **conserved**;
``serrated``    the *c* axis is doubled and a second layer is translated by
                the AA' offset, giving an ``AA'AA'`` sequence;
``staggered``   the *c* axis is doubled and the second layer is translated by
                the AB (pore-centre) offset;
``eclipsed``    the input monolayer itself (zero offset);
``rotated``     the *c* axis is doubled and the second layer is a symmetry
                operation of the first (rotation, mirror or transposition)
                instead of a translation.
==============  ===========================================================

Construction rules
------------------
Let the input have lattice rows **a**, **b** and **c** = (0, 0, c_e).

*Inclined.*  Keep **a** and **b**; replace **c** by ``(dx, dy, d)``, where
``d`` is the interlayer spacing and ``(dx, dy)`` the in-plane offset.  The
fractional atomic coordinates are carried over unchanged, so the atom count is
conserved — this is the structural signature of inclined AA stacking.  Note
that "unchanged" means fractional, not Cartesian: because **c** itself moved,
the same fractional coordinates describe a sheared cell, and the Cartesian
positions of the atoms shift by ``z * (dx, dy, 0)``.  That shear is exactly
what tilts the stack, and it is why the interlayer spacing is the
**z-component** of the new **c** rather than its length.

*Serrated / staggered.*  Keep **a** and **b**; set **c** = (0, 0, 2 c_e) and
place layer 1 at ``z = 0.25`` and layer 2 at ``z = 0.75``, with layer 2 equal
to layer 1 translated in-plane by the stacking offset.

Offset determination
--------------------
See :mod:`stacking_rules` for the definition of the two offsets and the values
recovered from the reference structures.  :class:`LayerStackingEngine` finds
them automatically by a two-stage procedure: a plane-group analysis followed,
if necessary, by a geometric search.
"""

from __future__ import annotations

import itertools
import math
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np
from scipy.spatial import KDTree

from cif_io import (
    LAYER_GAP_FRACTION,
    Structure,
)
from stacking_rules import (
    CANDIDATE_AXIS_SHIFTS,
    CANDIDATE_PORE_SHIFTS,
    DEFAULT_SYMMETRY_OP,
    PLANE_GROUP_OPS,
    PORE_FRACTIONAL_HEXAGONAL,
    PORE_FRACTIONAL_SQUARE,
    SYMMETRY_LAYER_SHIFT,
    SYMMETRY_OPS,
    pbc_shifts,
    symmetry_op,
)

__all__ = [
    "StackingResult",
    "LayerStackingEngine",
    "STACKING_MODES",
    "MODE_LABELS",
    "REFERENCE_AA_OFFSETS",
    "REFERENCE_AA_FRACTIONAL",
    "REFERENCE_CELLS",
    "AA_FRACTIONAL_HEXAGONAL",
    "AA_FRACTIONAL_SQUARE",
    "extract_monolayer",
]

STACKING_MODES = ("eclipsed", "inclined", "serrated", "staggered", "rotated")

MODE_LABELS = {
    "eclipsed": "Eclipsed AA-stacking",
    "inclined": "Inclined AA-stacking",
    "serrated": "Serrated AA-stacking",
    "staggered": "Staggered AB-stacking",
    "rotated": "Rotated / mirrored stacking",
}

#: (Removed constant) The doubled constructions previously compressed every
#: slab into a fixed 0.30 of the doubled c axis (``LAYER_Z_SPAN``).  Since the
#: revision responding to the JCIM review the slabs are placed RIGIDLY (see
#: :meth:`LayerStackingEngine._centred_monolayer`): the physical thickness *t*
#: of the sheet is preserved exactly, so in the doubled cell each slab spans
#: ``t / (2 c_e)`` and the interlayer gap is ``0.5 - t / (2 c_e)``.  For a
#: genuine monolayer (t < c_e) this gap always exceeds 0.25 of the new cell --
#: a *stronger* guarantee than the old fixed 0.20 -- and for the four benchmark
#: frameworks it is 0.325-0.5.  The detection threshold
#: :data:`cif_io.LAYER_GAP_FRACTION` (0.17) therefore keeps its margin on both
#: sides without any compression of the sheet geometry.

#: Default window (angstroms) for the AA' offset magnitude.
DEFAULT_AA_WINDOW = (1.00, 2.60)
#: Default window (angstroms) for the AB offset magnitude.
DEFAULT_AB_WINDOW = (2.00, None)
#: Empirical magnitude (angstroms) of the slipped-stack (AA') offset.
#: Measured for COF-1 (1.7157), COF-5 (1.5999), CTF-1 (1.6705) and
#: Pc-PBBA (1.5989); it is set by the local linker geometry and is therefore
#: not proportional to the lattice constant.  (1.74 A for CTF-1 is the
#: *static literature prediction*, not a measured value -- see SI 1.2.)
DEFAULT_AA_MAGNITUDE = 1.70

#: Exact fractional AA' offset for a **hexagonal** layer, ``(2/15, 1/15)`` of
#: the (a, b) lattice vectors.  This single vector reproduces the measured
#: reference offsets of COF-1 to 0.013 A and CTF-1 to 0.027 A, and because
#: ``b`` lies at 120 degrees it is exactly 30 degrees from the *a* axis in
#: Cartesian coordinates — the slip direction seen experimentally.  Its
#: exact magnitude is ``|a| * sqrt(3)/15`` = ``0.115470 |a|``.
#:
#: Do not confuse that with ``0.1146``, which appears in the older comments
#: in this project: it is the *measured* COF-1 offset as a fraction of its
#: cell (1.7157 A / 14.9640 A = 0.11466), not a rounding of the rule's
#: constant -- the rule's own value rounds to 0.1155, not 0.1146.
AA_FRACTIONAL_HEXAGONAL = (2.0 / 15.0, 1.0 / 15.0)

#: Exact fractional AA' offset for a **square** layer, ``(3/50, 7/200)``.
#: Reproduces the measured Pc-PBBA offset (0.0602, 0.0353) to 0.008 A.
AA_FRACTIONAL_SQUARE = (3.0 / 50.0, 7.0 / 200.0)

#: Measured AA' offsets of the reference structures, as
#: ``(magnitude in angstroms, direction in degrees relative to the a axis)``.
#: Recovered from the DFT-relaxed reference structures by circular averaging of
#: the per-atom layer-2-minus-layer-1 displacement.  For CTF-1 the inclined
#: value 1.6705 A; the static literature prediction for the same quantity
#: is 1.74 A (see SI 1.2).
#:
#: COF-5 is the one system whose slip is *along* **a** (0 degrees) rather
#: than at 30 degrees, which is why its fractional offset ``(0.0533, 0)``
#: does not follow :data:`AA_FRACTIONAL_HEXAGONAL`.  This is a real
#: difference between materials, not a defect of the rule: the slip direction
#: follows the linker geometry, and COF-5 has a different linker from COF-1
#: and CTF-1.  Supply the measured offset explicitly for COF-5.
REFERENCE_AA_OFFSETS: Dict[str, Tuple[float, float]] = {
    "COF-1": (1.7157, 29.88),
    "COF-5": (1.5999, 0.00),
    "CTF-1": (1.6705, 30.87),
    "Pc-PBBA": (1.5989, 30.41),
}

#: Measured AA' offsets as **fractional** (a, b) components.
REFERENCE_AA_FRACTIONAL: Dict[str, Tuple[float, float]] = {
    "COF-1": (0.132392, 0.065956),
    "COF-5": (0.053294, 0.000000),
    "CTF-1": (0.132850, 0.068207),
    "Pc-PBBA": (0.060176, 0.035319),
}

#: In-plane cell ``(|a|, |b|)`` of each reference system, in angstroms, used to
#: recognise a structure whose measured AA' offset we already know.  The
#: offset is chemical, so recognising the material is the only rigorous way to
#: supply it automatically.
REFERENCE_CELLS: Dict[str, Tuple[float, float]] = {
    "COF-1": (14.96397, 14.96397),
    "COF-5": (30.02000, 30.02000),
    "CTF-1": (14.52070, 14.51320),
    "Pc-PBBA": (22.91500, 22.91500),
}


#: Default tolerance (angstroms) for the rotated-mode symmetry validation.
#: The residual of a *correct* operation about the right axis is ~0.0001 A for
#: the ideal reference cells and stays below ~0.1 A for relaxed layers, while
#: a wrong operation about any axis is off by 1 A or more -- 0.35 A separates
#: the two regimes with the same margin the offset validation uses.
DEFAULT_SYMMETRY_TOL = 0.35

#: In-plane closest approach below which two layers count as sitting *on* each
#: other (node-on-node).  A correct staggered stack always clears the framework
#: by more than this -- even the tightest benchmark, COF-5, clears by 0.016 A --
#: while a node-on-node overlap is an exact coincidence (0 by construction).
NODE_ON_NODE_TOL = 0.01


def _reseat_slab(z: np.ndarray, centre: float) -> np.ndarray:
    """Translate fractional z coordinates so the slab is centred at ``centre``.

    Pure translation -- the spacing *between* the z coordinates is untouched,
    so the geometry of the sheet is preserved exactly.  Used when a slab may
    straddle the z = 0 boundary of its cell (e.g. after extracting a sheet
    from a parent cell, or after rescaling fractional z for a new c axis):
    the largest circular gap in the sorted coordinates is taken as the empty
    region opposite the slab, the slab is unwrapped from there, and the whole
    slab is then shifted rigidly so that its mid-plane sits on ``centre``.

    A genuine monolayer occupies less than half of its cell along z, so the
    centred slab always fits inside [0, 1) without wrapping again.
    """
    zs = np.sort(np.asarray(z, dtype=float) % 1.0)
    if zs.size == 0:
        return np.asarray(z, dtype=float)
    circular = np.concatenate([zs, [zs[0] + 1.0]])
    gaps = np.diff(circular)
    # unwrapped start: deliberately NOT taken modulo 1 -- the rounding of
    # ``zs[0] + 1.0`` can leave the value a few ulp above ``zs[0]``, and
    # wrapping it back would map the lowest atom of the slab to 0.9999...,
    # spreading the slab over the whole cell.
    start = float(circular[int(np.argmax(gaps)) + 1])
    unwrapped = (np.asarray(z, dtype=float) - start) % 1.0
    mid = 0.5 * (unwrapped.min() + unwrapped.max())
    return (unwrapped - mid + centre) % 1.0


@dataclass
class StackingResult:
    """Outcome of one stacking construction."""

    mode: str
    structure: Structure
    offset_frac: np.ndarray
    offset_cart: np.ndarray
    offset_magnitude: float
    interlayer_distance: float
    tilt_angle: float
    natoms_input: int
    natoms_output: int
    quality: float = 0.0
    offset_source: str = "auto"
    notes: List[str] = field(default_factory=list)
    #: For ``rotated`` stacking only: which symmetry operation related layer 2
    #: to layer 1 (a key of :data:`stacking_rules.SYMMETRY_OPS`).
    symmetry_op: str = ""
    #: For ``rotated`` stacking: the fractional in-plane centre the operation
    #: was applied about, and the largest same-species PBC displacement the
    #: operation leaves (0 means an exact symmetry operation of the layer).
    #: ``None`` when the residual was not measured.
    symmetry_axis: Tuple[float, float] = (0.0, 0.0)
    symmetry_residual: Optional[float] = None

    @property
    def c_length(self) -> float:
        return float(np.linalg.norm(self.structure.lattice[2]))

    @property
    def label(self) -> str:
        return MODE_LABELS.get(self.mode, self.mode)

    def summary(self) -> Dict[str, object]:
        out = {
            "mode": self.mode,
            "label": self.label,
            "natoms_input": int(self.natoms_input),
            "natoms_output": int(self.natoms_output),
            "offset_frac": [round(float(self.offset_frac[0]), 6),
                            round(float(self.offset_frac[1]), 6)],
            "offset_cart": [round(float(self.offset_cart[0]), 4),
                            round(float(self.offset_cart[1]), 4)],
            "offset_magnitude": round(float(self.offset_magnitude), 4),
            "interlayer_distance": round(float(self.interlayer_distance), 4),
            "tilt_angle": round(float(self.tilt_angle), 3),
            "c_length": round(self.c_length, 4),
            "quality": round(float(self.quality), 4),
            "offset_source": self.offset_source,
            "notes": list(self.notes),
        }
        if self.mode == "rotated":
            out["symmetry_axis"] = [round(float(self.symmetry_axis[0]), 4),
                                    round(float(self.symmetry_axis[1]), 4)]
            out["symmetry_residual"] = (None if self.symmetry_residual is None
                                        else round(float(self.symmetry_residual), 4))
        return out


class LayerStackingEngine:
    """Build inclined / serrated / staggered stacking from a monolayer.

    Parameters
    ----------
    structure:
        The input monolayer.
    symprec:
        Cartesian tolerance (angstroms) of the plane-group analysis.
    aa_window:
        Accepted magnitude range (angstroms) of the AA' offset.
    ab_window:
        Accepted magnitude range (angstroms) of the AB offset.

    Notes
    -----
    Layer separation is decided by :data:`cif_io.LAYER_GAP_FRACTION`
    (0.17 of the cell), reached through
    :meth:`Structure.layer_groups`.  There is deliberately no
    constructor argument for it: the threshold has to sit between the
    largest internal spacing of one sheet and the interlayer gap, and a
    caller-supplied value is what used to split a rippled CTF-1 layer in
    two.
    """

    def __init__(
        self,
        structure: Structure,
        symprec: float = 0.05,
        aa_window: Optional[Sequence[float]] = None,
        ab_window: Optional[Sequence[float]] = None,
        symmetry_tol: Optional[float] = None,
        _setting_fallback: bool = True,
        _check_2d: bool = True,
    ) -> None:
        self.structure = structure
        self.symprec = float(symprec)
        self.aa_window = tuple(aa_window) if aa_window else DEFAULT_AA_WINDOW
        self.ab_window = tuple(ab_window) if ab_window else DEFAULT_AB_WINDOW
        self.symmetry_tol = (float(symmetry_tol) if symmetry_tol is not None
                             else DEFAULT_SYMMETRY_TOL)

        self._bind(structure)
        #: Set when a non-standard setting was contracted on input
        #: (:func:`stacking_axis.contract_setting_bruteforce`).
        self.setting_note: Optional[str] = None
        #: Set when the (already accepted) input's extracted sheet is not
        #: itself a covalently periodic 2D net - recorded, not fatal, because
        #: the full input passed the two-dimensional check.
        self.sheet_note: Optional[str] = None

        if _check_2d:
            try:
                self._check_two_dimensional()
            except ValueError:
                if not _setting_fallback:
                    raise
                from stacking_axis import contract_setting_bruteforce
                contracted, note = contract_setting_bruteforce(self.structure)
                if note is None:
                    raise
                self._bind(contracted)
                self.setting_note = note
                self._check_two_dimensional()
        else:
            self._note_sheet_periodicity()

        self._pbc = pbc_shifts(1)
        self._aa_cache: Optional[Tuple[np.ndarray, float, str]] = None
        self._ab_cache: Optional[Tuple[np.ndarray, float, str]] = None
        #: Set by :meth:`ab_offset` when the conventional pore position of the
        #: lattice collides with the framework and the geometric search was
        #: used instead; ``(closest approach A, lattice type)``.
        self.pore_collision: Optional[Tuple[float, str]] = None

        # Pre-compute the periodic image cloud once: it is reused by every
        # nearest-neighbour query.
        cart = self.frac[:, :2] @ self._a2d
        self._cloud = np.vstack([cart + (s @ self._a2d) for s in self._pbc])
        self._cloud_species = np.tile(self.species, len(self._pbc))
        self._trees: Dict[str, KDTree] = {}
        for sym in sorted(set(map(str, self.species))):
            sel = self._cloud_species == sym
            self._trees[sym] = KDTree(self._cloud[sel])

    def _bind(self, structure: Structure) -> None:
        """(Re)bind all derived geometry to ``structure``."""
        self.structure = structure
        self.lattice = np.asarray(structure.lattice, dtype=float)
        self.frac = np.asarray(structure.frac_coords, dtype=float)
        self.species = structure.species_per_atom
        self._a2d = self.lattice[:2, :2]
        self._a2d_inv = np.linalg.inv(self._a2d)
        self.c_e = float(np.linalg.norm(self.lattice[2]))

    def _note_sheet_periodicity(self) -> None:
        """Record (do not raise) when the sheet is not a periodic 2D net.

        Called after the full input already passed
        :meth:`_check_two_dimensional` and a sheet was extracted from it: the
        extracted sheet can be a finite molecular fragment (the layers of the
        input were connected to each other, but each sheet alone is not
        covalently periodic in-plane).  The stacking constructions are pure
        geometry on the sheet, so the run continues; the note keeps the
        situation visible to the caller instead of hiding it.
        """
        from stacking_axis import _covalent_bond_graph, _cycle_displacements
        adj, natoms, _radii, _normal = _covalent_bond_graph(self.structure)
        cycles = _cycle_displacements(adj, natoms)
        in_plane = [d for d in cycles if d[0] != 0 or d[1] != 0]
        has_a = any(d[0] != 0 for d in in_plane)
        has_b = any(d[1] != 0 for d in in_plane)
        if not (has_a and has_b):
            self.sheet_note = ("the extracted sheet is not a covalently "
                               "periodic 2D net (the layers of the input were "
                               "mutually bonded, but the sheet alone is not "
                               "periodic in-plane)")

    def _check_two_dimensional(self) -> None:
        """Reject inputs that are not 2D layered materials.

        The test is representation-independent connectivity, not fractional
        coverage.  A 2D sheet is covalently periodic along *both* in-plane
        axes, so its bond graph closes cycles whose net displacement carries
        an a-component *and* cycles that carry a b-component.  A 1D chain
        closes cycles along one axis only, and an isolated molecule closes
        none.  The old fractional-gap version of this check misfired on
        non-standard but perfectly layered settings (an orthohexagonal
        representation of a hexagonal sheet was refused with "empty span
        along the b axis", because b' = a + 2b leaves a fractional void that
        is an artefact of the representation, not of the structure).
        """
        from stacking_axis import _covalent_bond_graph, _cycle_displacements
        adj, natoms, _radii, _normal = _covalent_bond_graph(self.structure)
        cycles = _cycle_displacements(adj, natoms)
        in_plane = [d for d in cycles if d[0] != 0 or d[1] != 0]
        has_a = any(d[0] != 0 for d in in_plane)
        has_b = any(d[1] != 0 for d in in_plane)
        if not (has_a and has_b):
            raise ValueError(
                "This structure does not look like a 2D layered material: "
                "its covalent network is not periodic along both in-plane "
                "axes. CrystalStacker builds interlayer stackings of 2D "
                "sheets and cannot process 1D chains or isolated molecules. "
                "(A 2D structure whose layers stack along a or b rather than "
                "c is *not* the problem this check reports: relabel its axes "
                "with stacking_axis.normalize_stacking_axis() before handing "
                "it to the engine.)"
            )

    # ================================================================== #
    # basic geometry
    # ================================================================== #
    @property
    def is_monolayer(self) -> bool:
        """``True`` when the structure is a single sheet.

        A sheet is *not* necessarily flat and is *not* necessarily one z-plane.
        The relaxed CTF-1 layer ripples over 0.35 of its own cell, and COF-1 is
        flat but has two chemically distinct sub-planes (B/O and C/H) 0.15
        apart; both are single sheets.  The test is therefore delegated to
        :meth:`Structure.layer_groups`, which separates genuine sheets
        from internal structure by looking at the widest gap.
        """
        return self.n_layers <= 1

    @property
    def n_layers(self) -> int:
        """Number of separate sheets.

        Delegates to :meth:`Structure.layer_groups` so that the layer
        count, the slab indices used by the builders and the monolayer test all
        share one definition and can never disagree.
        """
        return len(self.structure.layer_groups(None))

    @property
    def lattice_type(self) -> str:
        """``'hexagonal'``, ``'square'`` or ``'oblique'``, from the in-plane cell."""
        a = float(np.linalg.norm(self._a2d[0]))
        b = float(np.linalg.norm(self._a2d[1]))
        gamma = math.degrees(
            math.acos(np.clip(np.dot(self._a2d[0], self._a2d[1]) / (a * b), -1, 1))
        )
        if abs(a - b) < 0.05 and abs(gamma - 90.0) < 1.0:
            return "square"
        if abs(a - b) < 0.05 and abs(gamma - 120.0) < 1.0:
            return "hexagonal"
        return "oblique"

    def offset_to_cartesian(self, offset_frac: Sequence[float]) -> np.ndarray:
        return np.asarray(offset_frac, dtype=float)[:2] @ self._a2d

    def offset_to_fractional(self, offset_cart: Sequence[float]) -> np.ndarray:
        return np.asarray(offset_cart, dtype=float)[:2] @ self._a2d_inv

    # ================================================================== #
    # periodic nearest-neighbour machinery
    # ================================================================== #
    def nearest_distances(
        self,
        query_frac: np.ndarray,
        query_species: Optional[np.ndarray] = None,
    ) -> np.ndarray:
        """Distance from each query point to the closest original atom of the
        same element, periodic images included."""
        q = np.asarray(query_frac, dtype=float)[:, :2] @ self._a2d
        qsp = self.species if query_species is None else np.asarray(query_species, dtype=object)

        out = np.full(len(q), np.inf, dtype=float)
        for sym, tree in self._trees.items():
            sel = qsp == sym
            if not np.any(sel):
                continue
            d, _ = tree.query(q[sel], k=1)
            out[sel] = d
        return out

    def max_displacement(
        self,
        offset_frac: Sequence[float],
        query_frac: Optional[np.ndarray] = None,
        query_species: Optional[np.ndarray] = None,
    ) -> float:
        """Largest nearest-neighbour distance over all atoms of a shifted copy.

        .. warning::

            This is **not** a usable objective function for locating the AA'
            offset.  For any offset smaller than the shortest interatomic
            distance every atom finds its own periodic image first, so the
            value degenerates to ``|offset|`` and carries no gradient towards
            the stacking minimum.  It is retained only for symmetry testing
            (where the offset is a symmetry operation, not a slip) and is used
            as such by :meth:`plane_group_operations`.
        """
        base = self.frac if query_frac is None else np.asarray(query_frac, dtype=float)
        q = base.copy()
        q[:, 0] = q[:, 0] + float(offset_frac[0])
        q[:, 1] = q[:, 1] + float(offset_frac[1])
        return float(np.max(self.nearest_distances(q, query_species)))

    def min_separation(self, offset_frac: Sequence[float]) -> float:
        """Closest approach between two layers separated by ``offset_frac``.

        Used to *characterise* an offset (a large value means the layer sits
        over a void, a small value means atoms collide), not to search for one.
        """
        q = self.frac.copy()
        q[:, 0] = q[:, 0] + float(offset_frac[0])
        q[:, 1] = q[:, 1] + float(offset_frac[1])
        return float(np.min(self.nearest_distances(q, self.species)))

    # ================================================================== #
    # rotated-mode symmetry validation
    # ================================================================== #
    def symmetry_residual(
        self,
        key: str,
        axis: Sequence[float] = (0.0, 0.0),
    ) -> float:
        """How far ``op`` applied about ``axis`` is from being a symmetry
        operation of the monolayer.

        The residual is the largest same-species PBC displacement the
        transformed layer retains: ``0`` means every transformed atom lands
        exactly on an atom of the original layer, i.e. the operation *is* a
        symmetry operation about that axis; a value of several angstroms means
        the operation tears the layer apart and any stacking built from it
        would carry wrong bonding.

        The matrix acts about the fractional in-plane point ``p``:
        ``r -> p + M (r - p) = M r + (p - M p)``.  Applying the operation
        about the fractional origin -- which is what a naive build does --
        is only correct when the layer's own axis coincides with the origin,
        and that differs from material to material.
        """
        mat = symmetry_op(key)
        p = np.asarray(axis, dtype=float)[:2]
        q = self.frac[:, :2] @ mat.T + (p - p @ mat.T)
        return float(np.max(self.nearest_distances(q, self.species)))

    def best_symmetry_axis(
        self,
        key: str,
    ) -> Tuple[float, Tuple[float, float]]:
        """Best ``(residual, axis)`` for ``key`` over :data:`CANDIDATE_AXIS_SHIFTS`.

        The candidates cover the special positions of the hexagonal (p3, p6,
        c2mm) and square (p4, p4mm) plane groups -- the positions a rotation
        or mirror axis of a 2D net can sit on.  If even the best candidate
        exceeds :attr:`symmetry_tol`, the operation is not a symmetry
        operation of this layer and the caller must warn instead of silently
        stacking.
        """
        best: Tuple[float, Tuple[float, float]] = (math.inf, (0.0, 0.0))
        for cand in CANDIDATE_AXIS_SHIFTS:
            r = self.symmetry_residual(key, cand)
            if r < best[0]:
                best = (r, (float(cand[0]), float(cand[1])))
            if best[0] <= 1e-6:
                break
        return best

    # ================================================================== #
    # stage 1 -- plane-group analysis
    # ================================================================== #
    def plane_group_operations(self) -> List[Tuple[str, np.ndarray, np.ndarray, float]]:
        """Symmetry operations ``p -> M p + s`` of the monolayer.

        Returns ``(label, M, s, deviation)`` tuples with ``s`` the translation
        part in fractional in-plane coordinates.
        """
        ops: List[Tuple[str, np.ndarray, np.ndarray, float]] = []
        p = self.frac[:, :2]
        for label, mat in PLANE_GROUP_OPS:
            for sx, sy in CANDIDATE_AXIS_SHIFTS:
                shift = np.array([sx, sy])
                q = p @ mat.T + shift
                dev = self.max_displacement(np.zeros(2), q, self.species)
                if dev < self.symprec:
                    ops.append((label, mat, shift, dev))
        return ops

    def symmetry_axes(self) -> List[Tuple[str, np.ndarray, float]]:
        """In-plane rotation/mirror axes of the monolayer.

        Returns ``(label, direction, deviation)`` with ``direction`` a
        Cartesian unit vector.  A slipped layer slides along one of these
        directions, so this is what makes a *derivable* offset possible at
        all: the direction is fixed by symmetry even though the magnitude is
        a chemical parameter.
        """
        p_cart = self.frac[:, :2] @ self._a2d
        axes: List[Tuple[str, np.ndarray, float]] = []
        candidates = [
            np.array([1.0, 0.0]),
            np.array([0.0, 1.0]),
            np.array([1.0, 1.0]) / math.sqrt(2.0),
            np.array([1.0, -1.0]) / math.sqrt(2.0),
            np.array([0.5, math.sqrt(3.0) / 2.0]),
            np.array([-0.5, math.sqrt(3.0) / 2.0]),
        ]
        for label, mat in PLANE_GROUP_OPS:
            if np.allclose(mat, np.eye(2), atol=1e-8):
                continue
            for c in candidates:
                d = c / np.linalg.norm(c)
                refl = 2.0 * np.outer(d, d) - np.eye(2)
                q = (refl @ p_cart.T).T @ self._a2d_inv
                dev = float(np.max(self.nearest_distances(q, self.species)))
                if dev < self.symprec:
                    axes.append((label, d, dev))
        uniq: List[Tuple[str, np.ndarray, float]] = []
        for lab, d, dev in axes:
            if all(abs(abs(float(np.dot(d, u[1]))) - 1.0) > 1e-4 for u in uniq):
                uniq.append((lab, d, dev))
        return uniq

    def _symmetry_offsets(self) -> Tuple[List[np.ndarray], List[np.ndarray]]:
        """Candidate AA' and AB offsets from the plane-group analysis."""
        aa: List[np.ndarray] = []
        ab: List[np.ndarray] = []
        lo_a, hi_a = self.aa_window

        for label, mat, shift, _ in self.plane_group_operations():
            vec = shift - np.round(shift)
            mag = float(np.linalg.norm(vec @ self._a2d))

            if not np.allclose(mat, np.eye(2), atol=1e-8):
                # A rotation/mirror axis away from the origin produces a
                # symmetry-equivalent stacking vector.
                if lo_a <= mag <= hi_a:
                    aa.extend([vec, -vec])

            # Pore-centre (AB) candidates: the three-fold special positions.
            if label in ("C3", "C3^2", "C2", "m_d", "m_d'"):
                if mag >= 2.0:
                    ab.extend([shift, -shift])

        return aa, ab

    # ================================================================== #
    # stage 2 -- offset determination
    # ================================================================== #
    def _matches_known_system(self, tol: float = 0.05) -> Optional[str]:
        """Name of a reference system whose in-plane cell matches this one.

        The AA' offset is a chemical quantity that cannot be derived from an
        isolated monolayer (see :meth:`aa_offset`), so the only rigorous way to
        supply it automatically is to recognise a structure whose measured
        value we already have.  The fingerprint is the in-plane lattice
        (|a|, |b|, gamma), which is what fixes the offset's Cartesian length;
        a match within ``tol`` angstroms is taken to be the same material.
        """
        if self.lattice_type not in ("hexagonal", "square"):
            return None
        a = float(np.linalg.norm(self._a2d[0]))
        b = float(np.linalg.norm(self._a2d[1]))
        for name, (ra, rb) in REFERENCE_CELLS.items():
            if abs(a - ra) <= tol and abs(b - rb) <= tol:
                return name
        return None

    def _default_aa(self) -> Tuple[np.ndarray, float]:
        """The conventional AA' offset: an exact fraction of the unit cell.

        The slipped-stack offset is not an arbitrary chemical parameter after
        all — expressed in fractional coordinates it takes the same exact
        value for every hexagonal COF studied here:

            delta = (2/15, 1/15)  of  (a, b)

        That vector reproduces the measured offset of COF-1 to 0.013 A and of
        CTF-1 to 0.027 A.  Because ``b`` sits at 120 degrees, the Cartesian
        direction is exactly 30 degrees from ``a``, which is the slip
        direction observed in the reference structures (29.88 and 30.87
        degrees).  Its magnitude is ``0.1155 |a|``, i.e. ~1.7 A for the
        COF-1/CTF-1 cell — and it is this *fractional* constancy, not a fixed
        angstrom length, that explains why the offset looks lattice-dependent
        in Cartesian terms.

        **COF-5 is the exception.**  It slides along ``a`` (measured direction
        0.0 degrees) rather than at 30 degrees, with a fractional offset of
        ``(0.0533, 0.0000)`` — the values tabulated in
        :data:`REFERENCE_AA_FRACTIONAL`.  Applying the ``(2/15, 1/15)`` rule to
        it gives 3.466 A against a measured 1.600 A, a factor of 2.2 out.  The
        reason the rule fails there is that COF-5's slip direction lies *along
        one of the layer's own C2 axes* (0.0 degrees against a 0 degree axis),
        whereas in COF-1, CTF-1 and Pc-PBBA the slip direction is 30-60 degrees
        away from every symmetry axis.  A slip that follows a symmetry axis is
        a different chemical situation, and no fixed fractional rule covers
        both.

        Because the magnitude is a chemical parameter, the fall-back order is:

        1. a **recognised system** whose measured offset is tabulated in
           :data:`REFERENCE_AA_FRACTIONAL` (matched on the in-plane cell);
        2. the ``(2/15, 1/15)`` rule for hexagonal cells, ``(3/50, 7/200)``
           for square ones.

        When the chosen value comes from the rule but the layer's slip
        direction is *not* clearly resolved (see :meth:`aa_is_ambiguous`) the
        caller should treat it as needing confirmation — see
        :meth:`aa_offset`.
        """
        known = self._matches_known_system()
        if known is not None:
            frac = np.array(REFERENCE_AA_FRACTIONAL[known], dtype=float)
            return frac, float(np.linalg.norm(frac @ self._a2d))

        if self.lattice_type == "square":
            frac = np.array(AA_FRACTIONAL_SQUARE)
        else:
            frac = np.array(AA_FRACTIONAL_HEXAGONAL)
        return frac, float(np.linalg.norm(frac @ self._a2d))

    def aa_is_ambiguous(self) -> bool:
        """``True`` when the ``(2/15, 1/15)`` rule is probably not applicable.

        The AA' magnitude is chemical, so a rule-based value can be wrong for a
        new framework.  One situation is detectable from the monolayer alone:
        when the layer's slip direction would coincide with one of its own C2
        axes, the offset follows that axis instead of the rule — which is
        exactly what happens for COF-5.  A recognised system is never
        ambiguous.
        """
        if self._matches_known_system() is not None:
            return False
        axes = self.symmetry_axes()
        if not axes:
            return False
        rule = np.array(self._default_aa()[0], dtype=float)
        cart = rule @ self._a2d
        norm = float(np.linalg.norm(cart))
        if norm < 1e-9:
            return False
        udir = cart / norm
        # The rule sits at ~30 degrees from a in the hexagonal case.  If that
        # direction is within 3 degrees of a symmetry axis, or if a symmetry
        # axis exists at 0 degrees (which is the COF-5 pattern where the slip
        # runs along a), the rule cannot be trusted.
        for _, d, _ in axes:
            ang = math.degrees(math.acos(min(1.0, abs(float(np.dot(udir, d))))))
            if ang < 3.0:
                return True
            ax_ang = math.degrees(math.atan2(d[1], d[0])) % 180.0
            if ax_ang < 3.0 or abs(ax_ang - 180.0) < 3.0:
                return True
        return False

    def _geometric_ab_search(self, n: int = 121) -> Tuple[np.ndarray, float]:
        """Find the AB offset as the largest in-plane void of the monolayer.

        The point farthest from every atom is the pore centre; translating one
        layer by the vector to it gives the AB arrangement.

        The search is **order-independent and symmetry-independent**: it makes
        no assumption about where the pore sits, so it cannot be fooled by a
        cell whose void is off the high-symmetry grid.  The grid is refined by
        a local quadratic-style polish so that the returned vector is a
        genuine continuous maximum rather than a grid point.

        .. warning::

           On a **non-primitive** cell the deepest void can sit at a position
           whose shift merely maps the layer onto its own periodic image
           (node-on-node).  The search reports it anyway; :meth:`build_doubled`
           detects the coincidence and warns loudly, pointing the user at the
           manual in-plane offset -- the void depth alone cannot be trusted to
           pick a stacking.
        """
        def void_depth(pts_frac: np.ndarray) -> np.ndarray:
            d = np.full(len(pts_frac), np.inf)
            for sym, tree in self._trees.items():
                dd, _ = tree.query(pts_frac @ self._a2d, k=1)
                d = np.minimum(d, dd)
            return d

        grid = np.linspace(0.0, 1.0, n, endpoint=False)
        pts = np.array([[gx, gy] for gx in grid for gy in grid])
        d = void_depth(pts)

        # Candidate maxima: the global maximum, plus every other point that is
        # essentially as deep.  A cell with several equivalent pores gives
        # several such points; any of them is a valid AB vector.
        mx = float(np.max(d))
        order = np.argsort(d)[::-1]
        best: Optional[np.ndarray] = None
        for idx in order:
            if d[idx] < mx - 1e-6:
                break
            p = pts[idx]
            # A void at the origin is a lattice vector: not an offset.
            if np.allclose(p, 0.0, atol=1e-3):
                continue
            best = p
            break
        if best is None:
            # every deep point was at the origin -> take the largest non-origin
            for idx in order:
                p = pts[idx]
                if not np.allclose(p, 0.0, atol=1e-3):
                    best = p
                    mx = float(d[idx])
                    break
        if best is None:                       # degenerate: single atom cell
            best = np.array([0.5, 0.5])

        # Polish: hill-climb in fractional space with a shrinking step.
        step = 1.0 / n
        cur = np.array(best, dtype=float)
        cur_val = float(void_depth(cur.reshape(1, -1))[0])
        for _ in range(60):
            improved = False
            for dx in (-step, 0.0, step):
                for dy in (-step, 0.0, step):
                    if dx == 0.0 and dy == 0.0:
                        continue
                    cand = (cur + np.array([dx, dy])) % 1.0
                    v = float(void_depth(cand.reshape(1, -1))[0])
                    if v > cur_val + 1e-9:
                        cur, cur_val, improved = cand, v, True
            if not improved:
                step *= 0.5
                if step < 1e-6:
                    break
        return cur, cur_val

    def _snap_to_special_position(self, vec: np.ndarray) -> Optional[np.ndarray]:
        """Snap an offset onto a high-symmetry special position, if close."""
        best = None
        ref = float(np.linalg.norm(vec @ self._a2d))
        for sx, sy in CANDIDATE_PORE_SHIFTS:
            cand = np.array([sx, sy])
            mag = float(np.linalg.norm(cand @ self._a2d))
            if mag < 2.0:
                continue
            if abs(mag - ref) > 0.25 * max(ref, 1e-9) + 0.35:
                continue
            d = cand - vec
            d = d - np.round(d)
            dist = float(np.linalg.norm(d @ self._a2d))
            if best is None or dist < best[0]:
                best = (dist, cand)
        if best is None or best[0] > 1.0:
            return None
        return best[1]

    # ================================================================== #
    # offsets
    # ================================================================== #
    def aa_offset(self, force_search: bool = False) -> Tuple[np.ndarray, float, str]:
        """The AA' (serrated / inclined) offset.

        Returns ``(offset_frac, quality, source)``.

        The offset of a slipped stack is a *chemical* quantity — the second
        minimum of the interlayer PES.  For the COFs studied here it falls
        1.6-1.9 A from the origin along a symmetry direction of the layer and
        is **not** proportional to the lattice constant, so it cannot be
        derived from the isolated monolayer alone.  This method returns the
        closest derivable value: the shortest symmetry-consistent offset,
        paired with an empirical magnitude.  Pass ``offset`` explicitly to
        use a DFT-relaxed value from a PES scan.

        ``source`` is ``'symmetry'`` when a symmetry-consistent offset inside
        :attr:`aa_window` exists, otherwise ``'default'``.
        """
        if self._aa_cache is not None:
            return self._aa_cache[0].copy(), self._aa_cache[1], self._aa_cache[2]

        if not force_search:
            aa, _ = self._symmetry_offsets()
            if aa:
                best = None
                for vec in aa:
                    mag = float(np.linalg.norm(vec @ self._a2d))
                    if not (self.aa_window[0] <= mag <= self.aa_window[1]):
                        continue
                    if best is None or round(mag, 4) < best[0]:
                        best = (round(mag, 4), vec)
                if best is not None:
                    vec = self._canonical([best[1]])
                    self._aa_cache = (vec, float(best[0]), "symmetry")
                    return vec.copy(), float(best[0]), "symmetry"

        vec, mag = self._default_aa()
        known = self._matches_known_system()
        if known is not None:
            src = "reference:" + known
        elif self.aa_is_ambiguous():
            # The rule is probably not applicable to this framework; say so
            # instead of silently returning a value that may be off by 2x.
            src = "rule (unverified)"
        else:
            src = "default"
        vec = self._canonical([vec])
        real = float(np.linalg.norm(vec @ self._a2d))
        self._aa_cache = (vec, real, src)
        return vec.copy(), real, src

    def ab_offset(self) -> Tuple[np.ndarray, float, str]:
        """The AB (staggered) offset — the vector from a vertex to a pore centre.

        Returns ``(offset_frac, quality, source)`` with ``quality`` the
        clearance the offset leaves (large = the layer sits over a void).

        Determination
        -------------
        The pore centre of a 2D network is fixed by its **plane group**, not by
        a numeric ranking, so it is selected from the lattice type:

        * hexagonal (p6mm / p3) -> ``(2/3, 1/3)``
        * square    (p4mm)      -> ``(1/2, 1/2)``

        Both are verified against the reference structures: COF-1, COF-5 and
        CTF-1 all stagger by ``(2/3, 1/3)`` and Pc-PBBA by ``(1/2, 1/2)``.

        For a cell that is neither hexagonal nor square — or when the
        conventional pore position would drive the layers into each other — the
        geometric search below locates the void directly, and a low-symmetry
        cell that has an off-symmetry pore is handled by that fallback.

        .. warning::

           An earlier version ranked *all* candidates by
           :meth:`min_separation` and took the **largest** clearance.  The
           clearance is not a reliable discriminator: in COF-5 the true
           ``(2/3, 1/3)`` pore clears the framework by only 0.016 A while the
           non-pore ``(1/3, 1/3)`` clears by 0.073 A, and in the square Pc-PBBA
           cell the true ``(1/2, 1/2)`` clears by 0.71 A against 0.82 A for the
           non-pore ``(0, 1/2)``.  Ranking by clearance therefore *actively
           selected the wrong vector* for two of the four test systems.  The
           pore must be taken from the symmetry of the cell.
        """
        if self._ab_cache is not None:
            return self._ab_cache[0].copy(), self._ab_cache[1], self._ab_cache[2]

        lat = self.lattice_type
        if lat == "square":
            vec = np.array(PORE_FRACTIONAL_SQUARE)
            src = "symmetry"
        elif lat == "hexagonal":
            vec = np.array(PORE_FRACTIONAL_HEXAGONAL)
            src = "symmetry"
        else:
            vec, _ = self._geometric_ab_search()
            src = "geometric"

        vec = self._canonical([vec])
        sep = self.min_separation(vec)

        # Guard: if the conventional pore position would collide with the
        # framework the cell is not the high-symmetry type we assumed, so fall
        # back to the geometric search, which finds the actual void.  The
        # collision is recorded so the caller can warn: a cell whose
        # conventional pore position collides is usually non-primitive, and a
        # silently swapped search direction is exactly the kind of surprise
        # this tool must not spring on the user.
        if src == "symmetry" and sep <= 1e-3:
            self.pore_collision = (float(sep), lat)
            geo, geo_depth = self._geometric_ab_search()
            if geo_depth > sep:
                vec = self._canonical([geo])
                sep = self.min_separation(vec)
                src = "geometric"

        self._ab_cache = (vec, float(sep), src)
        return vec.copy(), float(sep), src

    def _canonical(self, vectors: Sequence[np.ndarray]) -> np.ndarray:
        """Fold a set of equivalent offsets onto a unique representative.

        Equivalents are the lattice translations together with the inversion
        ``v -> -v``; the representative is the one of smallest magnitude,
        ties broken by the smallest components.

        The result is folded into ``[-0.5, 0.5)`` — a *symmetric* wrap.  A
        plain ``v - floor(v)`` would send ``(-0.066, -0.131)`` to
        ``(0.934, 0.869)``, i.e. to the far corner of the cell, which is a
        different offset with a magnitude many times larger.
        """
        expanded: List[np.ndarray] = []
        for vec in vectors:
            base = np.asarray(vec, dtype=float).ravel()[:2]
            for sign in (1.0, -1.0):
                b = base * sign
                for shift in itertools.product((-1, 0, 1), repeat=2):
                    expanded.append(b + np.array(shift, dtype=float))
        if not expanded:
            expanded = [np.asarray(vectors[0], dtype=float).ravel()[:2]]

        def key(v: np.ndarray):
            # Ties on magnitude are broken towards the physically meaningful
            # representative: positive components along both lattice vectors.
            # The inversion ``-v`` describes the same periodic geometry, but
            # ``+v`` is the direction the layer actually slides, so it reads
            # correctly in the output (+30 degrees rather than 210).
            return (
                round(float(np.linalg.norm(v @ self._a2d)), 4),
                -round(float(v[0]), 4),
                -round(float(v[1]), 4),
            )

        chosen = min(expanded, key=key)
        return chosen - np.round(chosen)

    # ================================================================== #
    # construction
    # ================================================================== #
    def _centred_monolayer(self, z_scale: float = 0.5) -> np.ndarray:
        """Monolayer coordinates centred in z for a doubled cell.

        The geometry of the sheet is **invariant** under this operation.  The
        fractional z coordinates are converted to the doubled cell by the
        uniform factor ``z_scale = c_e / c_new`` and the slab is then
        *translated* -- never stretched -- so that it is centred on 0.25.
        Bond lengths, bond angles and the out-of-plane thickness of the sheet
        are preserved exactly, for flat and corrugated layers alike.

        (The previous implementation normalised the slab by its own z-span
        and compressed it to a fixed 0.30 of the doubled cell.  For a
        near-planar sheet that *amplified* numerical noise into corrugation:
        COF-1's 0.001 A thickness grew to 2.247 A and the B4-C8 bond stretched
        from 1.535 A to 2.140 A -- the defect reported in the JCIM review.
        For a rippled sheet such as CTF-1 the same operation *stretched* the
        physical 1.3 A buckling to 2.25 A.  Both distortions are gone.)

        A genuine monolayer has a physical thickness below ``c_e``, so in the
        doubled cell the slab spans less than 0.25 of ``c_new`` and the gap
        between the two layers is at least 0.25 of the new cell -- comfortably
        above :data:`cif_io.LAYER_GAP_FRACTION` (0.17), so both sheets are
        always recognised as separate layers without compressing anything.
        """
        frac = self.frac.copy()
        # fractional z w.r.t. the new cell, preserving physical z exactly
        frac[:, 2] = frac[:, 2] * float(z_scale)
        # rigid translation: re-seat the (possibly wrapped) slab on 0.25
        frac[:, 2] = _reseat_slab(frac[:, 2], centre=0.25)
        frac[:, :2] = frac[:, :2] - np.floor(frac[:, :2])
        return frac

    def build_eclipsed(self) -> StackingResult:
        """Re-emit the input monolayer (zero offset)."""
        return StackingResult(
            mode="eclipsed",
            structure=self.structure.copy(),
            offset_frac=np.zeros(2),
            offset_cart=np.zeros(2),
            offset_magnitude=0.0,
            interlayer_distance=self.c_e,
            tilt_angle=0.0,
            natoms_input=self.structure.natoms,
            natoms_output=self.structure.natoms,
            quality=0.0,
            offset_source="input",
            notes=["The input monolayer itself; the layer offset is zero."],
        )

    def build_inclined(
        self,
        offset: Optional[Sequence[float]] = None,
        interlayer_distance: Optional[float] = None,
    ) -> StackingResult:
        """Tilt the *c* vector by the in-plane offset, atoms fixed in space.

        Only the **c** lattice row changes: the atom count is identical to
        that of the input -- the structural signature of inclined AA stacking.

        The atomic positions are kept fixed **in Cartesian space** and
        re-expressed in the tilted cell.  Keeping the *fractional* coordinates
        instead would shear a corrugated sheet in proportion to its z: an atom
        a fraction z above the layer mid-plane is displaced in-plane by
        ``z * offset`` when the c row acquires the offset's in-plane
        components, which stretches bonds within a buckled layer (the second
        defect reported in the JCIM review).  Preserving the Cartesian
        positions keeps the sheet geometry exact; the periodic image across
        the new c vector is displaced by exactly ``offset`` + ``d``, which is
        the inclined stacking itself.
        """
        offset_frac, quality, source = self._resolve_offset(offset, mode="inclined")
        offset_cart = self.offset_to_cartesian(offset_frac)
        d = float(interlayer_distance) if interlayer_distance else self.c_e

        new_lattice = self.lattice.copy()
        new_lattice[2] = np.array([offset_cart[0], offset_cart[1], d])

        # Cartesian-preserving change of basis: physical positions unchanged.
        cart = self.frac @ self.lattice
        new_frac = cart @ np.linalg.inv(new_lattice)

        out = self.structure.copy()
        out.lattice = new_lattice
        out.frac_coords = new_frac

        magnitude = float(np.linalg.norm(offset_cart))
        tilt = math.degrees(math.atan2(magnitude, d))

        return StackingResult(
            mode="inclined",
            structure=out,
            offset_frac=offset_frac,
            offset_cart=offset_cart,
            offset_magnitude=magnitude,
            interlayer_distance=d,
            tilt_angle=tilt,
            natoms_input=self.structure.natoms,
            natoms_output=out.natoms,
            quality=float(quality),
            offset_source=source,
            notes=[
                "Only the c-vector is tilted; the atomic positions are kept "
                "fixed in Cartesian space, so the atom count is conserved "
                "and the sheet geometry is preserved exactly.",
                "The interlayer spacing d is the z-component of the new "
                "c-vector; it defaults to the c length of the input.",
            ],
        )

    def build_doubled(
        self,
        mode: str,
        offset: Optional[Sequence[float]] = None,
        interlayer_distance: Optional[float] = None,
    ) -> StackingResult:
        """Double the *c* axis and place a second layer at ``offset``.

        Used for ``serrated`` (AA' offset) and ``staggered`` (AB offset).
        Layer 2 is layer 1 translated by ``(delta, 0.5)`` in fractional
        coordinates and wrapped back into the cell.
        """
        if mode not in ("serrated", "staggered"):
            raise ValueError(
                "build_doubled() handles 'serrated' and 'staggered' only."
            )

        offset_frac, quality, source = self._resolve_offset(offset, mode=mode)
        offset_cart = self.offset_to_cartesian(offset_frac)

        # The interlayer distance d is the separation of the layer mid-planes
        # in the new cell (c_new = 2 d).  The sheet itself is placed rigidly:
        # its physical thickness is preserved, so the fractional z
        # coordinates are rescaled by c_e / c_new -- the exact coordinate
        # transformation for the new c axis, never a distortion.
        d = float(interlayer_distance) if interlayer_distance else self.c_e
        base = self._centred_monolayer(z_scale=self.c_e / (2.0 * d))
        layer1 = base.copy()
        layer2 = base.copy()
        layer2[:, 0] = (layer2[:, 0] + offset_frac[0]) % 1.0
        layer2[:, 1] = (layer2[:, 1] + offset_frac[1]) % 1.0
        layer2[:, 2] = layer2[:, 2] + 0.5

        # Keep the atoms grouped by species so the counts line stays valid.
        counts = list(self.structure.counts)
        order: List[int] = []
        n = len(base)
        cursor = 0
        for cnt in counts:
            order.extend(range(cursor, cursor + cnt))
            order.extend(range(n + cursor, n + cursor + cnt))
            cursor += cnt

        frac = np.vstack([layer1, layer2])[order]
        frac = frac - np.floor(frac)

        c_e = d
        new_lattice = self.lattice.copy()
        new_lattice[2] = np.array([0.0, 0.0, 2.0 * c_e])

        out = Structure(
            lattice=new_lattice,
            species=list(self.structure.species),
            counts=[c * 2 for c in counts],
            frac_coords=frac,
            title=self.structure.title,
        )

        notes = [
            "The c axis is doubled; layer 2 is layer 1 translated by the "
            "in-plane offset and by half of the new c axis.",
            "Layers are placed at z = 0.25 (layer 1) and z = 0.75 "
            "(layer 2).",
        ]
        if mode == "staggered":
            if quality < NODE_ON_NODE_TOL:
                # Node-on-node: the pore-centre vector mapped atoms exactly
                # onto atoms.  Happens when the cell is not primitive -- the
                # conventional (1/2, 1/2) of a doubled square cell moves a
                # node onto another node and the "staggered" stack is
                # indistinguishable from AA.  Never silent: point the user at
                # the manual offset.
                notes.insert(0, "WARNING: the pore-centre offset maps atoms "
                                "of layer 2 exactly onto atoms of layer 1 "
                                "(closest approach %.4f A). The input cell is "
                                "probably not primitive; enter the true pore "
                                "position by hand via the in-plane offset."
                                % quality)
            elif self.pore_collision:
                notes.insert(0, "WARNING: the conventional pore position of "
                                "the %s lattice coincides with framework "
                                "atoms of this cell (closest approach %.4f "
                                "A), so the pore was located by a geometric "
                                "search instead. Verify the result, or enter "
                                "a measured pore position via the in-plane "
                                "offset."
                                % (self.pore_collision[1],
                                   self.pore_collision[0]))

        return StackingResult(
            mode=mode,
            structure=out,
            offset_frac=offset_frac,
            offset_cart=offset_cart,
            offset_magnitude=float(np.linalg.norm(offset_cart)),
            interlayer_distance=c_e,
            tilt_angle=0.0,
            natoms_input=self.structure.natoms,
            natoms_output=out.natoms,
            quality=float(quality),
            offset_source=source,
            notes=notes,
        )

    def is_bilayer(self) -> bool:
        """Whether the input already holds two well-separated layers.

        A reference structure for the rotation family is a *finished* bilayer
        (two complete monolayers at z = 0 and z = 0.5), so mode (e) has to cope
        with being handed a stack rather than a monolayer.  Two conditions must
        both hold before the input is treated as a bilayer, so that a merely
        rippled monolayer is never mistaken for one:

        * the z coordinates cluster into exactly two groups, and
        * each group holds the same number of atoms of **every** species.
        """
        groups = self.structure.layer_groups()
        if len(groups) != 2:
            return False
        sp = self.structure.species_per_atom
        a = sorted(sp[groups[0]].tolist())
        b = sorted(sp[groups[1]].tolist())
        return len(a) > 0 and a == b

    def effective_monolayer(self) -> "LayerStackingEngine":
        """Return an engine on the monolayer of ``self``.

        If the input is already a bilayer (see :meth:`is_bilayer`) the first
        layer is extracted and returned as a new monolayer engine, with the
        **c** axis restored to a single layer thickness.  Otherwise ``self`` is
        returned unchanged.

        The extracted layer keeps only the species it actually contains, in the
        order they first appear, so the counts line of any structure built from
        it stays consistent.
        """
        if not self.is_bilayer():
            return self

        groups = self.structure.layer_groups()
        keep = groups[0]
        frac = self.structure.frac_coords[keep]
        sp_all = self.structure.species_per_atom
        sp = sp_all[keep]

        ordered_species: List[str] = []
        for s in sp:
            if s not in ordered_species:
                ordered_species.append(s)
        counts = [int((sp == s).sum()) for s in ordered_species]

        # reorder the coordinates into species blocks, which is how the
        # structure is stored and what the writer lays out
        idx: List[int] = []
        for s in ordered_species:
            idx.extend(np.where(sp == s)[0].tolist())
        frac = frac[idx]

        new_lat = self.lattice.copy()
        # The extracted layer occupies its own cell, not half of a doubled one.
        # A bilayer relaxed at c = 6.8 A has to come back at c = 3.4 A: the
        # builders below re-double the c axis of whatever they are handed, so
        # carrying the parent cell's interlayer vacuum along would double the
        # *interlayer spacing* of every generated stack instead of doubling the
        # layer thickness.  Same rule as the module-level extract_monolayer().
        n_layers = float(len(groups))
        new_lat[2] = new_lat[2] / n_layers

        # Resetting c to c / n_layers shortens the physical length of one
        # fractional z unit by the same factor -- the fractional coordinates
        # must therefore be scaled by n_layers to keep the *physical* z of
        # every atom (and with it the thickness and ripple of the sheet)
        # exactly as it was in the parent cell.  This is the exact coordinate
        # transformation for the new c axis; without it a bilayer's corrugated
        # sheet came back with half its buckling.
        frac = frac.copy()
        frac[:, 2] = _reseat_slab((frac[:, 2] * n_layers) % 1.0, centre=0.5)

        mono = Structure(
            lattice=new_lat,
            species=ordered_species,
            counts=counts,
            frac_coords=frac,
            title=self.structure.title,
        )
        return LayerStackingEngine(mono, _check_2d=False)

    def build_rotated(
        self,
        symmetry: str = "",
        interlayer_distance: Optional[float] = None,
    ) -> StackingResult:
        """Build an output-form **(e)** stack: layer 2 = ``op(layer 1) + c/2``.

        This is the rotation / mirror family of stacking: instead of sliding
        layer 2 in-plane, the second layer is the first one *reflected or
        rotated* about an axis, and then shifted by half of the doubled **c**
        axis.  The default operation is the transposition ``(x, y) -> (y, x)``,
        which is the relation measured in the reference bilayer
        (see :data:`stacking_rules.SYMMETRY_OPS`).

        Unlike ``inclined``/``serrated``/``staggered`` this mode does not use
        an in-plane offset vector, so ``offset_frac``/``offset_cart`` are
        reported as zero.  The atom count doubles, exactly as for
        ``serrated``/``staggered``.

        The input may be either a monolayer (the usual case) or an
        already-stacked bilayer, in which case the first layer is extracted
        first -- see :meth:`effective_monolayer`.

        Validation
        ----------
        The operation is first measured against the monolayer about the
        fractional origin (:meth:`symmetry_residual`).  If it is not a
        symmetry operation there, :meth:`best_symmetry_axis` searches the
        special positions for an axis the operation does hold about -- the
        axes of a 2D net need not sit at the origin (COF-1's transpose axis
        sits at (1/6, 5/6)-type positions).  Only when even the best axis
        leaves a residual above :attr:`symmetry_tol` is the result flagged:
        the note then says so in plain words and ``offset_source`` becomes
        ``"symmetry (unvalidated)"``, so a wrong stacking can never pass
        silently.
        """
        key = str(symmetry or DEFAULT_SYMMETRY_OP).lower().strip()
        mat = symmetry_op(key)                     # raises KeyError if unknown
        label = next(lab for k, lab, _m in SYMMETRY_OPS if k == key)

        # A reference bilayer is already stacked; work from its monolayer.
        src = self.effective_monolayer()
        was_bilayer = src is not self

        residual = src.symmetry_residual(key, (0.0, 0.0))
        axis = (0.0, 0.0)
        if residual > self.symmetry_tol:
            best_r, best_p = src.best_symmetry_axis(key)
            if best_r < residual:
                residual, axis = best_r, best_p
        validated = residual <= self.symmetry_tol
        source = "symmetry" if validated else "symmetry (unvalidated)"

        c_e_rot = float(interlayer_distance) if interlayer_distance else src.c_e
        base = src._centred_monolayer(
            z_scale=src.c_e / (2.0 * c_e_rot))
        layer1 = base.copy()

        # apply the symmetry operation about the chosen in-plane centre:
        # r -> p + M (r - p), in row-vector form
        p = np.array(axis, dtype=float)
        xy = layer1[:, :2] @ mat.T + (p - p @ mat.T)
        layer2 = np.column_stack([
            xy[:, 0] - np.floor(xy[:, 0]),
            xy[:, 1] - np.floor(xy[:, 1]),
            layer1[:, 2] + SYMMETRY_LAYER_SHIFT,
        ])

        # keep the atoms grouped by species so the counts line stays valid
        counts = list(src.structure.counts)
        order: List[int] = []
        n = len(base)
        cursor = 0
        for cnt in counts:
            order.extend(range(cursor, cursor + cnt))
            order.extend(range(n + cursor, n + cursor + cnt))
            cursor += cnt

        frac = np.vstack([layer1, layer2])[order]
        frac = frac - np.floor(frac)

        c_e = c_e_rot
        new_lattice = src.lattice.copy()
        new_lattice[2] = np.array([0.0, 0.0, 2.0 * c_e])

        out = Structure(
            lattice=new_lattice,
            species=list(src.structure.species),
            counts=[c * 2 for c in counts],
            frac_coords=frac,
            title=src.structure.title,
        )

        notes = [
            "Layer 2 is layer 1 transformed by the '%s' symmetry operation and "
            "shifted by half of the doubled c axis." % label,
            "No in-plane offset vector is used in this mode; the layers are "
            "related by symmetry instead.",
        ]
        if was_bilayer:
            notes.insert(
                0,
                "The input held two layers; the first layer was extracted and "
                "used as the monolayer before stacking.",
            )
        if validated:
            if any(axis):
                notes.append(
                    "The operation holds about the in-plane axis at (%.4f, "
                    "%.4f), not about the origin; the residual of the applied "
                    "operation is %.4f A." % (axis[0], axis[1], residual)
                )
        else:
            notes.insert(0, "WARNING: the '%s' operation is not a symmetry "
                            "operation of this layer about any candidate axis "
                            "(smallest PBC residual %.3f A, tolerance %.2f A). "
                            "The generated stacking is very likely wrong; pick "
                            "another operation or supply a validated one."
                            % (key, residual, self.symmetry_tol))

        return StackingResult(
            mode="rotated",
            structure=out,
            offset_frac=np.zeros(2),
            offset_cart=np.zeros(2),
            offset_magnitude=0.0,
            interlayer_distance=c_e,
            tilt_angle=0.0,
            natoms_input=src.structure.natoms,
            natoms_output=out.natoms,
            quality=1.0,
            offset_source=source,
            notes=notes,
            symmetry_op=key,
            symmetry_axis=axis,
            symmetry_residual=residual,
        )

    def build(
        self,
        mode: str,
        offset: Optional[Sequence[float]] = None,
        interlayer_distance: Optional[float] = None,
        symmetry: str = "",
    ) -> StackingResult:
        """Build one stacking configuration.

        Parameters
        ----------
        mode:
            One of ``eclipsed``, ``inclined``, ``serrated``, ``staggered``,
            ``rotated``.
        offset:
            Optional in-plane offset overriding the automatic determination.
            Two entries with both magnitudes at most 1 are interpreted as
            *fractional* coordinates, otherwise as Cartesian angstroms.
        interlayer_distance:
            Optional interlayer spacing overriding the default.
        symmetry:
            For ``rotated`` only: which symmetry operation relates layer 2 to
            layer 1.  Defaults to
            :data:`stacking_rules.DEFAULT_SYMMETRY_OP` (``"transpose"``).
        """
        mode = str(mode).lower().strip()
        if mode == "eclipsed":
            return self.build_eclipsed()
        if mode == "inclined":
            return self.build_inclined(offset, interlayer_distance)
        if mode in ("serrated", "staggered"):
            return self.build_doubled(mode, offset, interlayer_distance)
        if mode == "rotated":
            if offset is not None:
                raise ValueError(
                    "rotated stacking does not use an in-plane offset; pass "
                    "the symmetry operation instead."
                )
            return self.build_rotated(symmetry, interlayer_distance)
        raise ValueError(
            "Unknown stacking mode %r; expected one of %s."
            % (mode, ", ".join(STACKING_MODES))
        )

    def build_all(
        self,
        modes: Sequence[str] = ("inclined", "serrated", "staggered"),
        offset: Optional[Sequence[float]] = None,
        interlayer_distance: Optional[float] = None,
        symmetry: str = "",
    ) -> Dict[str, StackingResult]:
        """Build several configurations at once, keyed by mode name."""
        if offset is not None and len([m for m in modes if m in ("serrated", "staggered")]) > 1:
            raise ValueError(
                "A single manual offset cannot be shared by serrated and "
                "staggered stacking; build them one at a time instead."
            )
        return {
            m: self.build(m, offset, interlayer_distance, symmetry)
            for m in modes
        }

    def offset_table(self) -> List[Dict[str, object]]:
        """Both automatic offsets, with their quality metric and origin."""
        aa_f, aa_q, aa_src = self.aa_offset()
        ab_f, ab_q, ab_src = self.ab_offset()
        rows = []
        for name, vec, q, src in (("AA' (serrated)", aa_f, aa_q, aa_src),
                                  ("AB (staggered)", ab_f, ab_q, ab_src)):
            cart = self.offset_to_cartesian(vec)
            rows.append({
                "name": name,
                "offset_frac": [round(float(vec[0]), 6), round(float(vec[1]), 6)],
                "offset_cart": [round(float(cart[0]), 4), round(float(cart[1]), 4)],
                "magnitude": round(float(np.linalg.norm(cart)), 4),
                "quality": round(float(q), 4),
                "source": src,
            })
        return rows

    def extract_monolayer(self, layer_index: int = 0) -> Structure:
        """Convenience wrapper around :func:`extract_monolayer`."""
        return extract_monolayer(self.structure, layer_index)

    # ================================================================== #
    # internals
    # ================================================================== #
    def _resolve_offset(
        self,
        offset: Optional[Sequence[float]],
        mode: str,
    ) -> Tuple[np.ndarray, float, str]:
        """Return ``(offset_frac, quality, source)`` for one stacking mode."""
        if offset is None:
            if mode == "staggered":
                return self.ab_offset()
            return self.aa_offset()

        arr = np.asarray(offset, dtype=float).ravel()
        if arr.size < 2:
            raise ValueError("The offset needs at least two components.")
        vec = arr[:2]
        if np.allclose(vec, 0.0):
            return np.zeros(2), 0.0, "manual"

        # Values inside [-1, 1] are fractional, larger ones are angstroms.
        if np.all(np.abs(vec) <= 1.0):
            frac = vec - np.floor(vec)
        else:
            frac = (vec @ self._a2d_inv)
            frac = frac - np.floor(frac)

        quality = self.min_separation(frac)
        return self._canonical([frac]), float(quality), "manual"

# ---------------------------------------------------------------------- #
# monolayer extraction
# ---------------------------------------------------------------------- #
def extract_monolayer(structure: Structure, layer_index: int = 0) -> Structure:
    """Cut one sheet out of a multilayer structure and return it alone.

    This is the "extract a monolayer" entry point: hand it a multilayer CIF
    as read (e.g. a DFT-relaxed bilayer) and it returns the selected sheet as
    a standalone :class:`Structure` that can be fed back into
    :class:`LayerStackingEngine` or downloaded directly.  ``layer_index``
    selects the sheet, counted from the one at the lowest z.

    The **c** axis is reset to ``c / n_layers``, which is the monolayer cell
    of an evenly stacked input: a bilayer relaxed at c = 6.7 A comes back
    with c = 3.35 A instead of carrying the interlayer vacuum of the parent
    cell around.  The in-plane lattice is untouched, and the fractional z
    coordinates are scaled by ``n_layers`` (and the slab re-seated by a pure
    translation) so that the *physical* thickness and ripple of the sheet
    are exactly as they were in the parent cell -- see the note inside
    :meth:`LayerStackingEngine.effective_monolayer`.

    A structure with fewer than two sheets is returned unchanged (there is
    nothing to extract).
    """
    groups = structure.layer_groups()
    if layer_index < 0 or layer_index >= len(groups):
        raise ValueError(
            "layer_index %d is out of range: the structure holds %d layer(s)."
            % (layer_index, len(groups)))
    if len(groups) < 2:
        return structure.copy()

    keep = groups[layer_index]
    sp_all = structure.species_per_atom
    sp = sp_all[keep]

    # re-block the atoms by species in order of first appearance, which is
    # the layout the CIF writer (and every downstream count) expects
    ordered: List[str] = []
    for s in sp:
        s = str(s)
        if s not in ordered:
            ordered.append(s)
    counts = [int((sp == s).sum()) for s in ordered]
    idx: List[int] = []
    for s in ordered:
        idx.extend(np.where(sp == s)[0].tolist())
    frac = structure.frac_coords[keep][idx].copy()

    new_lat = np.asarray(structure.lattice, dtype=float).copy()
    n_layers = float(len(groups))
    new_lat[2] = new_lat[2] / n_layers

    # physical-z-preserving rescale to match the new c axis (see
    # effective_monolayer()); the slab may straddle z = 0 in the parent cell,
    # so it is re-seated by a rigid translation afterwards
    frac[:, 2] = _reseat_slab((frac[:, 2] * n_layers) % 1.0, centre=0.5)

    return Structure(
        lattice=new_lat,
        species=ordered,
        counts=counts,
        frac_coords=frac,
        title=structure.title,
    )

