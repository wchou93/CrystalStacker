#!/bin/sh
# Periodic GFN2-xTB optimisation of the generated serrated COF-1 stacking.
# Requires xtb >= 6.6 (https://www.xtb-docs.readthedocs.io).
xtb coord --opt tight --gfn 2 --periodic 3 > xtb.out 2> xtb.err
