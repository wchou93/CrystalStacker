# Geometry optimisation of generated stackings — worked example

CrystalStacker builds candidate stackings geometrically and does **not**
relax them.  This example shows the two smallest steps for crossing that
boundary, using two widely available periodic semi-empirical codes:

* **xTB** (GFN2-xTB, `xtb >= 6.6`) — `xtb_example/`
* **DFTB+** (`DFTB+ >= 19.1` with the 3ob/3-1 parameter set) — `dftbplus_example/`

Both examples start from the *serrated* (AA') output of COF-1 produced by
the tool (`COF-1_serrated.cif`, shipped next to this README).  Replace it
with any generated structure to repeat the workflow for a different case.

## Files

| file | purpose |
|---|---|
| `cif_to_opt_formats.py` | converts a generated CIF into both optimisation geometry formats: a Turbomole `coord` file (`$periodic 3`, `$cell`) for xTB and a `geo.gen` file for DFTB+ |
| `xtb_example/coord` | converted COF-1 serrated output |
| `xtb_example/run_xtb.sh` | the optimisation command line |
| `dftbplus_example/geo.gen` | converted COF-1 serrated output |
| `dftbplus_example/dftb_in.hsd` | DFTB+ input deck (periodic GFN-style setup, 3ob parameters) |

## xTB workflow

```bash
cd xtb_example
xtb coord --opt tight --gfn 2 --periodic 3 > xtb.out 2> xtb.err
```

* `--periodic 3` switches on three-dimensional periodic boundary conditions
  and reads the cell from the `$cell` block of the `coord` file;
* the optimised geometry is written to `xtbopt.coord` in the same format;
* the dispersion-corrected GFN2-xTB Hamiltonian is the recommended default
  for COF-like organic frameworks.

## DFTB+ workflow

```bash
cd dftbplus_example
dftb+ dftb_in.hsd > dftb.out 2> dftb.err
```

* the input deck loads the geometry from `geo.gen` (GenFormat) and runs a
  conjugated-gradient optimisation with D3 dispersion (as in the DFT
  references used for validation, which also employed dispersion
  correction);
* download the 3ob-3-1 Slater–Koster files (https://dftb.org/parameters/)
  and point `SlaterKosterFiles` at them before running;
* the optimised geometry is written to `geo_end.gen`.

## What "reproducible" means here

The input decks are complete and self-contained except for the
Slater–Koster files, which DFTB+ licences separately from this project.
Running the two commands above on the shipped `coord`/`geo.gen` files
reproduces the optimised starting points used for the interface examples in
the manuscript; no results of these optimisations are reported in the
manuscript itself — the examples only demonstrate how a generated stacking
enters an optimisation workflow.
