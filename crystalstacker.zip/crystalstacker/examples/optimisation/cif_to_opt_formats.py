# -*- coding: utf-8 -*-
"""Convert a generated CIF into the geometry formats of the optimisation codes.

cif_to_xtb_coord.py  -> Turbomole `coord` file for `xtb --periodic 3`
cif_to_gen.py        -> DFTB+ `geo.gen` file

Both scripts take the CIF path as the single argument:

    python cif_to_xtb_coord.py COF-1_serrated.cif      # writes ./coord
    python cif_to_gen.py        COF-1_serrated.cif     # writes ./geo.gen
"""
import math
import os
import sys

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.normpath(os.path.join(HERE, "..", "..")))

from cif_io import read_cif  # noqa: E402

BOHR = 0.52917721092  # Angstrom per bohr

ELEM_ORDER = None  # keep the CIF's species order


def _species_blocks(structure):
    """Per-atom species list in storage order."""
    return [str(s) for s in structure.species_per_atom]


def write_xtb_coord(structure, out_path="coord"):
    """Turbomole coord: Cartesian positions in bohr, cell as $cell block."""
    lines = ["$coord", ""]
    lat = structure.lattice
    sp = _species_blocks(structure)
    cart = structure.frac_coords @ lat
    for sym, xyz in zip(sp, cart):
        lines.append("%17.10f %17.10f %17.10f  %s"
                     % (xyz[0] / BOHR, xyz[1] / BOHR, xyz[2] / BOHR, sym.lower()))
    lines += ["", "$periodic 3", "$cell", ""]
    # a, b, c lengths and alpha, beta, gamma from the lattice rows
    va, vb, vc = lat[0], lat[1], lat[2]
    a, b, c = (float(np.linalg.norm(v)) for v in (va, vb, vc))
    alpha = math.degrees(math.acos(
        float(np.dot(vb, vc)) / (b * c)))
    beta = math.degrees(math.acos(
        float(np.dot(va, vc)) / (a * c)))
    gamma = math.degrees(math.acos(
        float(np.dot(va, vb)) / (a * b)))
    lines += ["%16.9f %16.9f %16.9f" % (a / BOHR, b / BOHR, c / BOHR),
              "%16.9f %16.9f %16.9f" % (alpha, beta, gamma), "$end"]
    with open(out_path, "w", encoding="utf-8") as fh:
        fh.write("\n".join(lines) + "\n")
    return out_path


def write_gen(structure, out_path="geo.gen"):
    """DFTB+ GenFormat: 'S' line (fractional + cell vectors)."""
    sp = _species_blocks(structure)
    symbols = []
    for s in sp:
        if s not in symbols:
            symbols.append(s)
    lat = structure.lattice
    lines = ["%d  S" % structure.natoms,
             " ".join(symbols)]
    order = {s: k + 1 for k, s in enumerate(symbols)}
    cart = structure.frac_coords @ lat
    # GenFormat wants coordinates in ANGSTROM (when the 'S' line is given
    # with the lattice in Angstrom) -- DFTB+ interprets the geometry block
    # in Angstrom by default for GenFormat
    for sym, xyz in zip(sp, cart):
        lines.append("%5d %16.9f %16.9f %16.9f" % (order[sym], xyz[0], xyz[1], xyz[2]))
    # origin + the three lattice vectors in Angstrom
    lines.append("0.000000000 0.000000000 0.000000000")
    for v in lat:
        lines.append("%16.9f %16.9f %16.9f" % tuple(v))
    with open(out_path, "w", encoding="utf-8") as fh:
        fh.write("\n".join(lines) + "\n")
    return out_path


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        return
    cif = sys.argv[1]
    structure = read_cif(cif)
    out1 = write_xtb_coord(structure, "coord")
    out2 = write_gen(structure, "geo.gen")
    print("wrote %s and %s from %s" % (out1, out2, os.path.basename(cif)))


if __name__ == "__main__":
    main()
