# -*- coding: utf-8 -*-
"""Self-contained test suite for the 2D layer-stacking engine.

Runs without pytest::

    python test_layer_stacking.py

Every check is reported as ``ok`` / ``FAIL`` and the exit status is non-zero
if any check fails.

The offset checks in section 3b/4b are **gold-standard**: the expected values
are the offsets recovered from the reference structures themselves by a grid
scan of the residual (slide layer 2 back and measure how well it lands on
layer 1).  The residuals of that recovery are 0.01-0.06 A, so the expected
values are good to better than 0.1 A and they are independent of the engine's
own logic.

An earlier version of this file asserted the engine's *own* output as expected
(``COF-5 AB magnitude ~ (1/3, 1/3)``, with a 35 % + 1 A tolerance) which is why
two real bugs went unnoticed: the engine offset COF-5 by 2.1x and both COF-5
and Pc-PBBA by the wrong pore vector.  Tolerances below are tight on purpose;
a failure here means the engine regressed, not the test.
"""

from __future__ import annotations

import io
import math
import sys
import os

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from cif_io import read_cif, write_cif, Structure  # noqa: E402
from layer_stacking import (  # noqa: E402
    LayerStackingEngine,
    REFERENCE_AA_FRACTIONAL,
    REFERENCE_AA_OFFSETS,
    REFERENCE_CELLS,
    AA_FRACTIONAL_HEXAGONAL,
    AA_FRACTIONAL_SQUARE,
)

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
REFERENCE = os.path.join(HERE, "reference")

#: True offsets recovered from the reference structures by grid-scanning the
#: interlayer residual (see the module docstring).  Fractional (a, b).
TRUE_OFFSETS = {
    ("COF-1", "serrated"): (0.13463, 0.06790),
    ("COF-1", "staggered"): (-0.33216, 0.33451),
    ("COF-5", "serrated"): (0.05556, 0.00117),
    ("COF-5", "staggered"): (-0.32716, 0.33451),
    ("CTF-1", "serrated"): (0.13463, 0.06790),
    ("CTF-1", "staggered"): (-0.31481, 0.32716),
    ("Pc-PBBA", "serrated"): (0.06056, 0.03586),
    ("Pc-PBBA", "staggered"): (-0.50000, -0.50000),
}

#: A reference structure is a separate DFT relaxation, so its cell and its
#: atomic positions differ slightly from the input monolayer.  CTF-1 is the
#: loosest case at 0.32 A (4 % of the offset); everything else is under 0.18 A.
OFFSET_TOL = 0.35

_failures = []
_checks = 0


def check(name: str, condition: bool, detail: str = "") -> None:
    global _checks
    _checks += 1
    if condition:
        print("  ok    %s" % name)
    else:
        print("  FAIL  %s   %s" % (name, detail))
        _failures.append(name)


def close(name: str, got: float, want: float, tol: float) -> None:
    check(name, abs(got - want) <= tol,
          "got %.4f want %.4f (tol %.4f)" % (got, want, tol))


def offset_error(got_frac: np.ndarray, true_frac, a2d: np.ndarray) -> float:
    """Smallest in-plane separation between two offsets, modulo the lattice
    translations and the inversion that describe the same periodic geometry."""
    got = np.asarray(got_frac, dtype=float)
    true = np.asarray(true_frac, dtype=float)
    best = np.inf
    for sx in (-2, -1, 0, 1, 2):
        for sy in (-2, -1, 0, 1, 2):
            for sign in (1.0, -1.0):
                cand = sign * true + np.array([sx, sy], dtype=float)
                best = min(best, float(np.linalg.norm((got - cand) @ a2d)))
    return best


def max_layer_deviation(a: Structure, b: Structure):
    """Largest same-species in-plane mismatch between two structures."""
    if len(a.frac_coords) != len(b.frac_coords):
        return None
    fa = a.frac_coords[:, :2]
    fb = b.frac_coords[:, :2]
    vb = b.lattice[:2, :2]
    sa = a.species_per_atom
    sb = b.species_per_atom
    worst = 0.0
    for i in range(len(fa)):
        sel = sb == sa[i]
        if not sel.any():
            return None
        cand = fb[sel]
        best = np.inf
        for ix in (-1, 0, 1):
            for iy in (-1, 0, 1):
                d = (cand + np.array([ix, iy]) - fa[i]) @ vb
                best = min(best, float(np.linalg.norm(d, axis=1).min()))
        worst = max(worst, best)
    return worst


def load(system: str, name: str) -> Structure:
    return read_cif(os.path.join(REFERENCE, system, name))


# --------------------------------------------------------------------- #
# 1. CIF reader
# --------------------------------------------------------------------- #
print("CIF reader")
src = load("COF-1", "eclipsed-AA.cif")
check("COF-1 atom count", src.natoms == 42, "got %d" % src.natoms)
check("COF-1 formula", src.formula.replace(" ", "") == "B6O6C18H12",
      "got %r" % src.formula)
close("COF-1 a length", src.abc[0], 14.96397, 1e-4)
close("COF-1 c length", src.abc[2], 3.74507, 1e-4)

ser = load("COF-1", "serrated-AA.cif")
check("serrated atom count", ser.natoms == 84, "got %d" % ser.natoms)
check("serrated counts doubled", ser.counts == [12, 12, 36, 24],
      "got %s" % ser.counts)

# the reader must ignore a trailing velocity block
tmp = os.path.join(HERE, "_tmp_roundtrip.cif")
write_cif(src, tmp)
back = read_cif(tmp)
check("round-trip atom count", back.natoms == src.natoms)
check("round-trip lattice", bool(np.allclose(back.lattice, src.lattice)))
os.remove(tmp)

# --------------------------------------------------------------------- #
# 2. layer analysis
# --------------------------------------------------------------------- #
print("layer analysis")
for system in ("COF-1", "COF-5", "CTF-1", "Pc-PBBA"):
    s = load(system, "eclipsed-AA.cif")
    eng = LayerStackingEngine(s)
    check("%s is a monolayer" % system, eng.is_monolayer)
    check("%s has one layer" % system, eng.n_layers == 1, "got %d" % eng.n_layers)

check("COF-1 lattice is hexagonal",
      LayerStackingEngine(load("COF-1", "eclipsed-AA.cif")).lattice_type == "hexagonal")
check("Pc-PBBA lattice is square",
      LayerStackingEngine(load("Pc-PBBA", "eclipsed-AA.cif")).lattice_type == "square")
check("COF-5 lattice is hexagonal",
      LayerStackingEngine(load("COF-5", "eclipsed-AA.cif")).lattice_type == "hexagonal")

# --------------------------------------------------------------------- #
# 3a. AA' offset -- recognition of the tabulated systems
# --------------------------------------------------------------------- #
print("AA' offset: recognised systems")
for system in ("COF-1", "COF-5", "CTF-1", "Pc-PBBA"):
    eng = LayerStackingEngine(load(system, "eclipsed-AA.cif"))
    a2d = eng._a2d
    got, _quality, source = eng.aa_offset()
    err = offset_error(got, REFERENCE_AA_FRACTIONAL[system], a2d)
    check("%s AA' matches its measured value (< %.2f A)" % (system, OFFSET_TOL),
          err < OFFSET_TOL, "error %.4f A, source=%s" % (err, source))
    check("%s AA' is recognised by cell match" % system,
          source == "reference:" + system, "got source=%r" % source)
    check("%s AA' is not flagged ambiguous" % system, not eng.aa_is_ambiguous())

# the recognition must be driven by the cell, not by the file name
fake = load("COF-1", "eclipsed-AA.cif")
check("COF-1 cell fingerprint is tabulated",
      abs(fake.abc[0] - REFERENCE_CELLS["COF-1"][0]) < 0.05)

# --------------------------------------------------------------------- #
# 3b. AA' offset -- GOLD STANDARD against the reference structures
# --------------------------------------------------------------------- #
print("AA' offset: gold standard (engine vs reference structures)")
n_ok = 0
for system in ("COF-1", "COF-5", "CTF-1", "Pc-PBBA"):
    eng = LayerStackingEngine(load(system, "eclipsed-AA.cif"))
    got, _quality, source = eng.aa_offset()
    true = TRUE_OFFSETS[(system, "serrated")]
    err = offset_error(got, true, eng._a2d)
    n_ok += bool(err < OFFSET_TOL)
    check("%s serrated offset matches the reference (< %.2f A)" % (system, OFFSET_TOL),
          err < OFFSET_TOL,
          "got (%+.5f,%+.5f) true (%+.5f,%+.5f) error %.4f A [%s]" % (
              got[0], got[1], true[0], true[1], err, source))
check("all four serrated offsets pass", n_ok == 4, "%d/4" % n_ok)

# --------------------------------------------------------------------- #
# 3c. AA' offset -- the hexagonal / square rules themselves
# --------------------------------------------------------------------- #
print("AA' offset: fractional rules")
# The rule must reproduce COF-1 and CTF-1 (which are NOT the same cell size,
# so this tests the fractional -- not the angstrom -- constancy).
for system in ("COF-1", "CTF-1"):
    s = load(system, "eclipsed-AA.cif")
    rule = np.array(AA_FRACTIONAL_HEXAGONAL) @ s.lattice[:2, :2]
    true = np.array(TRUE_OFFSETS[(system, "serrated")]) @ s.lattice[:2, :2]
    close("%s hexagonal rule reproduces the slip (angstroms)" % system,
          float(np.linalg.norm(rule)), float(np.linalg.norm(true)), 0.06)
# The *physical* invariant: for a hexagonal cell with |a| = |b| = c and
# gamma = 120, (2/15, 1/15) @ a2d has the exact magnitude
#     |f|^2 = (2/15)^2 - (2/15)(1/15) + (1/15)^2 = 3/225 = 1/75
#     |f|   = sqrt(3)/15 = 0.1154701...  |a|
# (0.1146, which older comments quote, is the measured COF-1 offset over its
#  cell -- 1.7157 / 14.9640 -- and not a rounding of this constant)
#
# The tolerance is 1e-6, not machine epsilon: the CIF carries 8 decimal
# places, and |b| is stored as 12.95917560 rather than 12.95917561..., which
# alone shifts the ratio by ~5e-8.  That is input rounding, not an error in
# the rule.
_s_hex = load("COF-1", "eclipsed-AA.cif")
_hex_shift = float(np.linalg.norm(np.array(AA_FRACTIONAL_HEXAGONAL) @ _s_hex.lattice[:2, :2]))
_hex_a = float(np.linalg.norm(_s_hex.lattice[0, :2]))
close("hexagonal rule magnitude is exactly sqrt(3)/15 |a| = 0.115470|a|",
      _hex_shift / _hex_a, math.sqrt(3.0) / 15.0, 1e-6)
print("        (|a| = %.5f A -> |delta| = %.4f A)" % (_hex_a, _hex_shift))
close("hexagonal rule is exactly 30 deg from a",
      math.degrees(math.atan2((np.array(AA_FRACTIONAL_HEXAGONAL) @
                               np.array([[1.0, 0.0], [-0.5, math.sqrt(3) / 2]]))[1],
                              (np.array(AA_FRACTIONAL_HEXAGONAL) @
                               np.array([[1.0, 0.0], [-0.5, math.sqrt(3) / 2]]))[0])),
      30.0, 0.01)

# A new framework must NOT be silently given a value that may be 2x wrong:
# scaling COF-5's cell breaks the recognition and must raise the flag.
newcell = load("COF-5", "eclipsed-AA.cif")
newcell.lattice = newcell.lattice * 1.10
eng = LayerStackingEngine(newcell)
_off, _q, source = eng.aa_offset()
check("unrecognised COF-5-like cell is flagged", source == "rule (unverified)",
      "got %r" % source)
check("unrecognised COF-5-like cell reports ambiguity", eng.aa_is_ambiguous())

newcell2 = load("COF-1", "eclipsed-AA.cif")
newcell2.lattice = newcell2.lattice * 1.10
eng2 = LayerStackingEngine(newcell2)
_off2, _q2, source2 = eng2.aa_offset()
check("unrecognised COF-1-like cell is not flagged", source2 == "default",
      "got %r" % source2)
check("unrecognised COF-1-like cell is not ambiguous", not eng2.aa_is_ambiguous())

# --------------------------------------------------------------------- #
# 4a. AB offset -- selection by lattice type
# --------------------------------------------------------------------- #
print("AB offset: lattice type")
from stacking_rules import PORE_FRACTIONAL_HEXAGONAL, PORE_FRACTIONAL_SQUARE  # noqa: E402
for system, want in (("COF-1", PORE_FRACTIONAL_HEXAGONAL),
                     ("COF-5", PORE_FRACTIONAL_HEXAGONAL),
                     ("CTF-1", PORE_FRACTIONAL_HEXAGONAL),
                     ("Pc-PBBA", PORE_FRACTIONAL_SQUARE)):
    eng = LayerStackingEngine(load(system, "eclipsed-AA.cif"))
    ab, quality, source = eng.ab_offset()
    err = offset_error(ab, want, eng._a2d)
    check("%s AB is the %s pore" % (system, "hexagonal" if want == PORE_FRACTIONAL_HEXAGONAL
                                    else "square"),
          err < 0.05, "error %.4f A, source=%s" % (err, source))

# --------------------------------------------------------------------- #
# 4b. AB offset -- GOLD STANDARD against the reference structures
# --------------------------------------------------------------------- #
print("AB offset: gold standard (engine vs reference structures)")
n_ok = 0
for system in ("COF-1", "COF-5", "CTF-1", "Pc-PBBA"):
    eng = LayerStackingEngine(load(system, "eclipsed-AA.cif"))
    got, _quality, source = eng.ab_offset()
    true = TRUE_OFFSETS[(system, "staggered")]
    err = offset_error(got, true, eng._a2d)
    n_ok += bool(err < OFFSET_TOL)
    check("%s staggered offset matches the reference (< %.2f A)" % (system, OFFSET_TOL),
          err < OFFSET_TOL,
          "got (%+.5f,%+.5f) true (%+.5f,%+.5f) error %.4f A [%s]" % (
              got[0], got[1], true[0], true[1], err, source))
check("all four staggered offsets pass", n_ok == 4, "%d/4" % n_ok)

# The staggered offset must differ from the serrated one -- if the engine ever
# returns the same vector for both, one of them is wrong.
for system in ("COF-1", "COF-5", "CTF-1", "Pc-PBBA"):
    eng = LayerStackingEngine(load(system, "eclipsed-AA.cif"))
    aa, _, _ = eng.aa_offset()
    ab, _, _ = eng.ab_offset()
    check("%s serrated and staggered offsets differ" % system,
          offset_error(aa, ab, eng._a2d) > 0.5)

# --------------------------------------------------------------------- #
# 5. construction: atom counts and geometry
# --------------------------------------------------------------------- #
print("construction")
for system in ("COF-1", "COF-5", "CTF-1", "Pc-PBBA"):
    s = load(system, "eclipsed-AA.cif")
    eng = LayerStackingEngine(s)
    n = s.natoms
    inc = eng.build("inclined")
    check("%s inclined conserves atoms" % system, inc.natoms_output == n,
          "%d -> %d" % (n, inc.natoms_output))
    ser_ = eng.build("serrated")
    check("%s serrated doubles atoms" % system, ser_.natoms_output == 2 * n,
          "%d -> %d" % (n, ser_.natoms_output))
    stg = eng.build("staggered")
    check("%s staggered doubles atoms" % system, stg.natoms_output == 2 * n,
          "%d -> %d" % (n, stg.natoms_output))
    check("%s inclined c-vector is tilted" % system,
          abs(inc.structure.lattice[2][2] - s.abc[2]) < 1e-6)
    check("%s serrated c is doubled" % system,
          abs(ser_.c_length - 2 * s.abc[2]) < 1e-6,
          "%.4f vs %.4f" % (ser_.c_length, 2 * s.abc[2]))
    # a doubled build must actually contain two separated layers
    groups = stg.structure.layer_groups(None)
    check("%s staggered has two layers" % system, len(groups) == 2,
          "%d groups" % len(groups))
    if len(groups) == 2:
        check("%s staggered layers are equal in size" % system,
              len(groups[0]) == len(groups[1]), "%d vs %d" % (len(groups[0]), len(groups[1])))

# the inclined mode must keep the atoms fixed in CARTESIAN space: only the
# c row of the lattice changes and the fractional coordinates are
# re-expressed in the tilted cell (they change!).  Carrying the fractional
# coordinates over unchanged instead shears a corrugated sheet in
# proportion to z -- the second defect reported in the JCIM review.
def _min_image_dist(lattice, fi, fj):
    d = fj - fi
    d -= np.round(d)
    return float(np.linalg.norm(d @ lattice))


for system in ("COF-1", "COF-5", "CTF-1", "Pc-PBBA"):
    s = load(system, "eclipsed-AA.cif")
    eng = LayerStackingEngine(s)
    inc = eng.build("inclined")
    out = inc.structure
    cart_in = s.frac_coords @ s.lattice
    cart_out = out.frac_coords @ out.lattice
    check("%s inclined keeps every atom at its Cartesian position" % system,
          bool(np.allclose(cart_in, cart_out, atol=1e-8)),
          "max |shift| %.2e A"
          % float(np.abs(cart_in - cart_out).max()))
    check("%s inclined changes only the c row of the lattice" % system,
          bool(np.allclose(out.lattice[:2], s.lattice[:2])))

# --------------------------------------------------------------------- #
# 5b. geometry preservation (JCIM revision, reviewer 1)
# --------------------------------------------------------------------- #
# Every stacking mode must leave the sheet itself untouched: identical
# intra-layer pair distances and identical out-of-plane thickness.  The
# pre-revision code compressed each slab to a fixed 0.30 of the doubled
# cell, which amplified the numerical thickness of near-planar COF-1
# (0.001 A) into 2.247 A of corrugation and stretched its B4-C8 bond from
# 1.535 A to 2.140 A; the inclined mode sheared corrugated sheets.
print("geometry preservation (JCIM revision)")


def _layer1_rows(structure_in, structure_out):
    """Rows of ``structure_out`` that hold the rigid copy of the input sheet.

    The doubled builders interleave layer 1 and layer 2 in species blocks:
    for each species block of the input, first the layer-1 rows, then the
    layer-2 rows.  For single-layer outputs every row is layer 1.
    """
    if structure_out.natoms == structure_in.natoms:
        return list(range(structure_in.natoms))
    n = structure_in.natoms
    order = []
    cursor = 0
    for cnt in structure_in.counts:
        order.extend(range(cursor, cursor + cnt))
        order.extend(range(n + cursor, n + cursor + cnt))
        cursor += cnt
    return [p for p, b in enumerate(order) if b < n]


def _thickness(structure, rows):
    """Physical z-extent of the given rows (a, b lie in the xy-plane)."""
    z = structure.frac_coords[rows, 2]
    return float((z.max() - z.min()) * structure.lattice[2][2])


def _rigid_deviation(s_in, s_out, rows_out):
    """Largest 3D positional deviation of the output sheet from the input.

    The output sheet must be the input sheet translated as a whole (the
    stacking construction may translate it along z and wrap atoms across the
    cell boundary, but it may never move one atom relative to another).
    Whole-lattice translations are snapped away before measuring, so a pure
    wrap counts as zero and any internal distortion shows up in angstroms.
    """
    c_in = s_in.frac_coords @ s_in.lattice
    c_out = s_out.frac_coords[rows_out] @ s_out.lattice
    shift = (c_out - c_in).mean(axis=0)
    d = c_out - c_in - shift
    f = d @ np.linalg.inv(s_in.lattice)     # input-basis components
    f -= np.round(f)                        # snap away whole translations
    return float(np.abs(f @ s_in.lattice).max())


for system in ("COF-1", "COF-5", "CTF-1", "Pc-PBBA"):
    s = load(system, "eclipsed-AA.cif")
    eng = LayerStackingEngine(s)
    t_in = _thickness(s, range(s.natoms))
    for mode in ("eclipsed", "inclined", "serrated", "staggered", "rotated"):
        res = eng.build(mode)
        out = res.structure
        rows = _layer1_rows(s, out)
        dev = _rigid_deviation(s, out, rows)
        check("%s %s places the sheet rigidly (3D positions)" % (system, mode),
              dev < 1e-7, "max deviation %.2e A" % dev)
        t_out = _thickness(out, rows)
        check("%s %s preserves the sheet thickness" % (system, mode),
              abs(t_out - t_in) < 1e-7,
              "%.4f -> %.4f A" % (t_in, t_out))

# the reviewer's own test case: the B4-C8 bond of the provided COF-1
# monolayer must survive every construction unchanged
_c1_labels = {}
with open(os.path.join(REFERENCE, "COF-1", "eclipsed-AA.cif"),
          encoding="utf-8") as _fh:
    _in_sites = False
    for _line in _fh:
        _t = _line.strip()
        if _t.startswith("_atom_site_label"):
            _in_sites = True
            continue
        if _t.startswith("_") or _t.startswith("loop_") or not _t:
            continue
        if _in_sites:
            _p = _t.split()
            if len(_p) >= 5:
                _c1_labels[_p[0]] = (str(_p[1]), np.array([float(_v) for _v in _p[2:5]]))

s_c1 = load("COF-1", "eclipsed-AA.cif")
eng_c1 = LayerStackingEngine(s_c1)
sp_c1 = s_c1.species_per_atom


def _label_index(label):
    el, xyz = _c1_labels[label]
    hits = []
    for i in range(s_c1.natoms):
        if str(sp_c1[i]) != el:
            continue
        d = (s_c1.frac_coords[i] - xyz + 0.5) % 1.0 - 0.5
        if np.allclose(d, 0.0, atol=2e-4):
            hits.append(i)
    assert len(hits) == 1, (label, hits)
    return hits[0]


_iB4, _iC8 = _label_index("B4"), _label_index("C8")
_d_bc_in = _min_image_dist(s_c1.lattice, s_c1.frac_coords[_iB4],
                           s_c1.frac_coords[_iC8])
close("COF-1 B4-C8 reference bond length", _d_bc_in, 1.5354, 1e-3)
for _mode in ("eclipsed", "inclined", "serrated", "staggered", "rotated"):
    _res = eng_c1.build(_mode)
    _rows = _layer1_rows(s_c1, _res.structure)
    _single = _res.structure.natoms == s_c1.natoms
    _pB = _iB4 if _single else _rows[_iB4]
    _pC = _iC8 if _single else _rows[_iC8]
    _d_bc = _min_image_dist(_res.structure.lattice,
                            _res.structure.frac_coords[_pB],
                            _res.structure.frac_coords[_pC])
    check("COF-1 B4-C8 bond survives %s stacking" % _mode,
          abs(_d_bc - _d_bc_in) < 1e-7,
          "%.4f -> %.4f A" % (_d_bc_in, _d_bc))

# --------------------------------------------------------------------- #
# 6. offline reproduction of the reference structures
# --------------------------------------------------------------------- #
print("reference reproduction (serrated, measured offset)")
# Feeding the *measured* offset must reproduce the reference structure itself.
# This validates the construction, independently of the offset choice.
for system in ("COF-1", "COF-5", "CTF-1", "Pc-PBBA"):
    s = load(system, "eclipsed-AA.cif")
    eng = LayerStackingEngine(s)
    off = list(REFERENCE_AA_FRACTIONAL[system])
    ref = load(system, "serrated-AA.cif")
    res = eng.build("serrated", offset=off)
    check("%s serrated atom count matches reference" % system,
          res.structure.natoms == ref.natoms,
          "%d vs %d" % (res.structure.natoms, ref.natoms))
    # in-plane displacement between the two layers of the generated structure
    # must equal the requested offset
    g = res.structure.layer_groups(None)
    if len(g) == 2:
        a2d = res.structure.lattice[:2, :2]
        lo = res.structure.frac_coords[g[0]][:, :2]
        hi = res.structure.frac_coords[g[1]][:, :2]
        # match per species to get the rigid shift
        sp = res.structure.species_per_atom
        d = []
        for sym in set(map(str, sp)):
            ca = lo[sp[g[0]] == sym]
            cb = hi[sp[g[1]] == sym]
            if len(ca) == len(cb) and len(ca):
                dv = cb - ca
                dv -= np.round(dv)
                d.append(dv.mean(axis=0))
        if d:
            shift = np.mean(d, axis=0)
            err = offset_error(shift, off, a2d)
            check("%s serrated layers are separated by the requested offset" % system,
                  err < 0.05, "error %.4f A" % err)

# --------------------------------------------------------------------- #
# 7. manual override plumbing
# --------------------------------------------------------------------- #
print("manual override")
eng = LayerStackingEngine(load("COF-1", "eclipsed-AA.cif"))
r1 = eng.build("serrated", offset=[0.10, 0.05])
r2 = eng.build("serrated", offset=[0.20, 0.10])
check("manual fractional offset is respected",
      not np.allclose(r1.offset_frac, r2.offset_frac))
check("manual offset reports source", r1.offset_source == "manual",
      "got %r" % r1.offset_source)

r3 = eng.build("inclined", offset=[2.0, 1.0])  # angstroms
check("cartesian offset is interpreted in angstroms",
      abs(r3.offset_magnitude - math.hypot(2.0, 1.0)) < 1e-6,
      "got %.4f" % r3.offset_magnitude)

# a manual offset must reach the output structure
eng_c5 = LayerStackingEngine(load("COF-5", "eclipsed-AA.cif"))
manual = list(REFERENCE_AA_FRACTIONAL["COF-5"])
res_manual = eng_c5.build("serrated", offset=manual)
g = res_manual.structure.layer_groups(None)
if len(g) == 2:
    sp = res_manual.structure.species_per_atom
    lo = res_manual.structure.frac_coords[g[0]][:, :2]
    hi = res_manual.structure.frac_coords[g[1]][:, :2]
    d = []
    for sym in set(map(str, sp)):
        ca = lo[sp[g[0]] == sym]
        cb = hi[sp[g[1]] == sym]
        if len(ca) == len(cb) and len(ca):
            dv = cb - ca
            dv -= np.round(dv)
            d.append(dv.mean(axis=0))
    if d:
        shift = np.mean(d, axis=0)
        check("COF-5 manual override lands on the requested offset",
              offset_error(shift, manual, res_manual.structure.lattice[:2, :2]) < 0.05)

try:
    eng.build("nonsense")
    check("unknown mode is rejected", False, "no exception raised")
except ValueError:
    check("unknown mode is rejected", True)

# --------------------------------------------------------------------- #
# 8. rotated mode -- symmetry validation (defect report D-1)
# --------------------------------------------------------------------- #
print("rotated mode: symmetry validation")
from stacking_rules import SYMMETRY_OPS, CANDIDATE_AXIS_SHIFTS  # noqa: E402

# the two new preset angles exist and act as honest 60 / 300 degree rotations
_m60 = dict((k, m) for k, _l, m in SYMMETRY_OPS)["rot60"]
_m300 = dict((k, m) for k, _l, m in SYMMETRY_OPS)["rot300"]
_hex = np.array([[1.0, 0.0], [-0.5, math.sqrt(3) / 2]])   # a, b as columns frame
_a_img = _m60 @ np.array([1.0, 0.0])
close("rot60 maps a onto a+b", float(np.linalg.norm(_a_img @ _hex - (np.array([1, 0]) + np.array([0, 1])) @ _hex)), 0.0, 1e-9)
_a_img300 = _m300 @ np.array([1.0, 0.0])
close("rot300 maps a onto -b", float(np.linalg.norm(_a_img300 @ _hex - (np.array([0, -1])) @ _hex)), 0.0, 1e-9)

# COF-5: the transpose is an exact symmetry operation about the origin.
eng = LayerStackingEngine(load("COF-5", "eclipsed-AA.cif"))
res = eng.build("rotated", symmetry="transpose")
check("COF-5 transpose validates about the origin",
      res.symmetry_residual is not None and res.symmetry_residual < 1e-3,
      "residual %s" % res.symmetry_residual)
check("COF-5 transpose source is validated symmetry",
      res.offset_source == "symmetry", "got %r" % res.offset_source)
check("COF-5 transpose raises no warning",
      not any(n.startswith("WARNING") for n in res.notes))
check("COF-5 rotated result carries axis/residual in its summary",
      res.summary().get("symmetry_residual") is not None)

# COF-1: the transpose fails about the origin but is exact about an axis at
# (1/6, 5/6)-type positions -- the axis search must find it (defect D-1).
eng_c1 = LayerStackingEngine(load("COF-1", "eclipsed-AA.cif"))
r_origin = eng_c1.symmetry_residual("transpose", (0.0, 0.0))
check("COF-1 transpose is NOT a symmetry operation about the origin",
      r_origin > 1.0, "residual %.4f" % r_origin)
best_r, best_p = eng_c1.best_symmetry_axis("transpose")
check("COF-1 transpose validates about a searched axis",
      best_r < eng_c1.symmetry_tol, "residual %.4f at %s" % (best_r, best_p))
res_c1 = eng_c1.build("rotated", symmetry="transpose")
check("COF-1 rotated build uses the searched axis",
      abs(res_c1.symmetry_axis[0] - best_p[0]) < 1e-6
      and abs(res_c1.symmetry_axis[1] - best_p[1]) < 1e-6,
      "axis %s" % (res_c1.symmetry_axis,))
check("COF-1 rotated transpose validates end to end",
      res_c1.offset_source == "symmetry"
      and res_c1.symmetry_residual < eng_c1.symmetry_tol)

# CTF-1: the buckled relaxed layer has no exact operation; the engine must
# say so loudly instead of stacking silently.
eng_ctf = LayerStackingEngine(load("CTF-1", "eclipsed-AA.cif"))
res_ctf = eng_ctf.build("rotated", symmetry="rot120")
check("CTF-1 rot120 is flagged unvalidated",
      res_ctf.offset_source == "symmetry (unvalidated)",
      "got %r" % res_ctf.offset_source)
check("CTF-1 rot120 carries a WARNING note",
      any(n.startswith("WARNING") and "not a symmetry operation" in n
          for n in res_ctf.notes))
check("CTF-1 rot120 residual exceeds the tolerance",
      res_ctf.symmetry_residual > eng_ctf.symmetry_tol,
      "residual %s" % res_ctf.symmetry_residual)

# --------------------------------------------------------------------- #
# 9. staggered node-on-node diagnostic (defect report D-1, root cause 2)
# --------------------------------------------------------------------- #
print("staggered node-on-node detection")

def make_supercell(s: Structure, na: int, nb: int) -> Structure:
    """na x nb in-plane supercell, keeping the species-block layout."""
    lat = s.lattice.copy()
    lat[0] *= na
    lat[1] *= nb
    syms, fracs = [], []
    for ia in range(na):
        for ib in range(nb):
            for k in range(s.natoms):
                syms.append(s.species_per_atom[k])
                f = s.frac_coords[k].copy()
                fracs.append([(f[0] + ia) / na, (f[1] + ib) / nb, f[2]])
    return Structure.from_blocks(lattice=lat, symbols=syms,
                                 frac_coords=np.array(fracs),
                                 title=s.title + " supercell")

base_pbba = load("Pc-PBBA", "eclipsed-AA.cif")
eng_ok = LayerStackingEngine(base_pbba)
res_ok = eng_ok.build("staggered")
check("primitive Pc-PBBA staggered raises no warning",
      not any(n.startswith("WARNING") for n in res_ok.notes))

supercell = make_supercell(base_pbba, 2, 2)
eng_sup = LayerStackingEngine(supercell)
check("2x2 Pc-PBBA supercell is still typed square",
      eng_sup.lattice_type == "square", "got %r" % eng_sup.lattice_type)
res_sup = eng_sup.build("staggered")
check("non-primitive cell staggered is diagnosed, never silent",
      any(n.startswith("WARNING") and "maps atoms of layer 2" in n
          for n in res_sup.notes),
      "notes: %s" % res_sup.notes[:1])
check("non-primitive cell staggered is detected as node-on-node",
      res_sup.quality < 0.01, "quality %.4f" % res_sup.quality)
check("the warning points the user at the manual offset",
      any("in-plane offset" in n for n in res_sup.notes if n.startswith("WARNING")))

res_node = eng_sup.build("staggered", offset=[0.5, 0.5])
check("manual (1/2,1/2) on a non-primitive cell triggers node-on-node",
      any(n.startswith("WARNING") and "maps atoms of layer 2" in n
          for n in res_node.notes),
      "notes: %s" % res_node.notes[:1])
check("node-on-node quality is an exact coincidence",
      res_node.quality < 1e-6, "quality %.6f" % res_node.quality)

# --------------------------------------------------------------------- #
# 10. monolayer extraction
# --------------------------------------------------------------------- #
print("monolayer extraction")
from layer_stacking import extract_monolayer, _reseat_slab  # noqa: E402

mono_in = load("COF-1", "serrated-AA.cif")          # bilayer, c = 6.80 A
check("serrated reference holds two layers", mono_in.n_z_layers == 2)
mono = extract_monolayer(mono_in, 0)
check("extracted layer has the monolayer atom count", mono.natoms == 42,
      "got %d" % mono.natoms)
# the reference file lists O first, the monolayer B first; compare the
# species-count multiset rather than the storage order
check("extracted layer keeps the formula",
      sorted(mono.formula.split()) == sorted("B6 O6 C18 H12".split()),
      "got %r" % mono.formula)
close("extracted c is reset to one layer", mono.abc[2],
      mono_in.abc[2] / 2.0, 1e-6)
second = extract_monolayer(mono_in, 1)
check("second layer extracts too", second.natoms == 42)
check("layer_index out of range is rejected", False, "no exception") if False else None
try:
    extract_monolayer(mono_in, 5)
    check("layer_index out of range is rejected", False, "no exception raised")
except ValueError:
    check("layer_index out of range is rejected", True)
solo = load("COF-1", "eclipsed-AA.cif")
check("a monolayer input extracts to itself",
      extract_monolayer(solo, 0).natoms == solo.natoms)

# effective_monolayer() -- what the web application uses for bilayer inputs --
# must reset the c axis the same way.  Carrying the parent cell's doubled c
# along would make the builders double the *interlayer spacing* instead of the
# layer thickness, and every generated stack would be twice too tall.
bilayer_engine = LayerStackingEngine(mono_in)
check("the reference bilayer is recognised as a bilayer",
      bilayer_engine.is_bilayer())
eff = bilayer_engine.effective_monolayer().structure
check("effective_monolayer keeps one sheet", eff.natoms == 42,
      "got %d" % eff.natoms)
close("effective_monolayer resets c to one layer thickness", eff.abc[2],
      mono_in.abc[2] / 2.0, 1e-6)
close("effective_monolayer halves the cell volume",
      float(np.linalg.det(eff.lattice)),
      float(np.linalg.det(mono_in.lattice)) / 2.0, 1e-6)
stacked = LayerStackingEngine(eff).build("serrated")
close("the stack from a reduced bilayer keeps the reference spacing",
      stacked.interlayer_distance, mono_in.abc[2] / 2.0, 1e-6)

# extraction must preserve the PHYSICAL geometry of the sheet (JCIM
# revision): resetting c to c / n_layers shortens one fractional z unit, so
# the fractional z coordinates have to be scaled up by n_layers.  Without
# that, a corrugated sheet came back with half its buckling.
def _z_thickness(structure):
    z = structure.frac_coords[:, 2]
    return float((z.max() - z.min()) * structure.lattice[2][2])


_parent_groups = mono_in.layer_groups()
_t_layer0 = ((mono_in.frac_coords[_parent_groups[0]][:, 2].max()
              - mono_in.frac_coords[_parent_groups[0]][:, 2].min())
             * mono_in.lattice[2][2])
close("extract_monolayer preserves the physical sheet thickness",
      _z_thickness(mono), _t_layer0, 1e-6)
close("effective_monolayer preserves the physical sheet thickness",
      _z_thickness(eff), _t_layer0, 1e-6)
# the extracted sheet must still be one contiguous slab after the rescale
check("extracted sheet is one z-slab", mono.n_z_layers == 1,
      "got %d" % mono.n_z_layers)
check("reduced bilayer sheet is one z-slab", eff.n_z_layers == 1,
      "got %d" % eff.n_z_layers)
# and the re-seated slab must sit inside the cell without wrapping
check("extracted slab does not straddle the cell boundary",
      bool(np.all((mono.frac_coords[:, 2] > 1e-6)
                  & (mono.frac_coords[:, 2] < 1.0 - 1e-6))))

# _reseat_slab floating-point regression: a near-flat slab whose lowest atom
# sits a few ulp below the unwrapping start must stay one contiguous slab.
# (The first implementation wrapped the start back into [0, 1), which mapped
# the lowest atom to 0.9999... and spread the slab over the whole cell --
# value-dependent, so it hit the SI table regeneration but not the builders.)
_rng = np.random.default_rng(0)
_worst_span = 0.0
for _ in range(200):
    _c = float(_rng.uniform(0.05, 0.95))
    _z = _c + _rng.uniform(-5e-5, 5e-5, 42)
    _o = _reseat_slab(_z, centre=0.5)
    _worst_span = max(_worst_span, float(_o.max() - _o.min()))
check("re-seat keeps a near-flat slab contiguous (fp regression)",
      _worst_span < 1e-3, "worst span %.2e" % _worst_span)

# --------------------------------------------------------------------- #
# 11. non-layered input rejection and CIF symmetry transparency
# --------------------------------------------------------------------- #
print("input validation and CIF transparency")

chain_cif = os.path.join(HERE, "_tmp_chain.cif")
with io.open(chain_cif, "w", encoding="utf-8") as fh:
    fh.write("""data_chain
_cell_length_a 20.0
_cell_length_b 20.0
_cell_length_c 4.0
_cell_angle_alpha 90.0
_cell_angle_beta 90.0
_cell_angle_gamma 90.0
loop_
_atom_site_label
_atom_site_type_symbol
_atom_site_fract_x
_atom_site_fract_y
_atom_site_fract_z
C1 C 0.10 0.50 0.50
C2 C 0.30 0.50 0.50
C3 C 0.50 0.50 0.50
C4 C 0.70 0.50 0.50
""")
try:
    LayerStackingEngine(read_cif(chain_cif))
    check("1D chain is rejected", False, "no exception raised")
except ValueError as exc:
    check("1D chain is rejected", "2D layered material" in str(exc),
          "got %r" % str(exc)[:80])
os.remove(chain_cif)

# symmetry transparency: a declared group without operations must be
# reported, not silently read as its asymmetric unit
bad_cif = os.path.join(HERE, "_tmp_nosym.cif")
with io.open(bad_cif, "w", encoding="utf-8") as fh:
    fh.write("""data_nosym
_cell_length_a 10.0
_cell_length_b 10.0
_cell_length_c 10.0
_cell_angle_alpha 90.0
_cell_angle_beta 90.0
_cell_angle_gamma 90.0
_symmetry_space_group_name_H-M 'P 6/m m m'
loop_
_atom_site_label
_atom_site_type_symbol
_atom_site_fract_x
_atom_site_fract_y
_atom_site_fract_z
C1 C 0.10 0.20 0.30
""")
try:
    read_cif(bad_cif)
    check("declared group without operations is rejected", False,
          "no exception raised")
except ValueError as exc:
    check("declared group without operations is rejected",
          "symmetry operations" in str(exc), "got %r" % str(exc)[:80])
os.remove(bad_cif)

# a symmetric file WITH operations expands and reports the expansion
sym_cif = os.path.join(HERE, "_tmp_sym.cif")
with io.open(sym_cif, "w", encoding="utf-8") as fh:
    fh.write("""data_sym
_cell_length_a 10.0
_cell_length_b 10.0
_cell_length_c 10.0
_cell_angle_alpha 90.0
_cell_angle_beta 90.0
_cell_angle_gamma 90.0
_symmetry_space_group_name_H-M 'P -1'
loop_
_symmetry_equiv_pos_as_xyz
'x, y, z'
'-x, -y, -z'
loop_
_atom_site_label
_atom_site_type_symbol
_atom_site_fract_x
_atom_site_fract_y
_atom_site_fract_z
C1 C 0.10 0.20 0.30
""")
s_sym = read_cif(sym_cif)
check("expanded file doubles the site", s_sym.natoms == 2, "got %d" % s_sym.natoms)
check("expansion note records what happened",
      "1 sites x 2 operations" in s_sym.expansion_note,
      "got %r" % s_sym.expansion_note)
os.remove(sym_cif)

# an explicit P1 file without operations passes through without a note
p1_cif = os.path.join(HERE, "_tmp_p1.cif")
with io.open(p1_cif, "w", encoding="utf-8") as fh:
    fh.write("""data_p1
_cell_length_a 10.0
_cell_length_b 10.0
_cell_length_c 10.0
_cell_angle_alpha 90.0
_cell_angle_beta 90.0
_cell_angle_gamma 90.0
loop_
_atom_site_label
_atom_site_type_symbol
_atom_site_fract_x
_atom_site_fract_y
_atom_site_fract_z
C1 C 0.10 0.20 0.30
""")
check("explicit P1 without operations reads cleanly",
      read_cif(p1_cif).expansion_note == "")
os.remove(p1_cif)

# --------------------------------------------------------------------- #
# stacking-axis relabelling
#
# The layer normal of a published CIF need not be c.  A stack written along b
# or a is the same material, and must be relabelled rather than rejected.
# --------------------------------------------------------------------- #
from stacking_axis import (  # noqa: E402
    c_direction_bonds,
    normalize_stacking_axis,
    periodic_axes,
    stacking_axis,
)


def _permute_axes(structure, order):
    """Rebuild ``structure`` with its axes renamed (used to *make* the test
    inputs: a c-stacked monolayer relabelled into a b- or a-stacked cell)."""
    return Structure(
        lattice=np.asarray(structure.lattice, dtype=float)[list(order)],
        species=list(structure.species),
        counts=list(structure.counts),
        frac_coords=np.asarray(structure.frac_coords, dtype=float)[:, list(order)],
        title=structure.title,
    )


mono = read_cif(os.path.join(HERE, "examples", "COF-1_monolayer.cif"))
check("a c-stacked monolayer reports c as the stacking axis",
      stacking_axis(mono) == 2, "got %r" % stacking_axis(mono))

# abc -> bca puts the old c (the stack) onto b; abc -> cab puts it onto a.
# Both are *cyclic* permutations, which is what the tool itself uses and what
# keeps the test inputs right-handed, like a published CIF.
b_stacked = _permute_axes(mono, (1, 2, 0))
a_stacked = _permute_axes(mono, (2, 0, 1))
check("both test inputs are right-handed, as a published CIF would be",
      np.linalg.det(b_stacked.lattice) > 0
      and np.linalg.det(a_stacked.lattice) > 0)
check("a b-stacked cell is recognised (stacking axis b)",
      stacking_axis(b_stacked) == 1, "got %r" % stacking_axis(b_stacked))
check("an a-stacked cell is recognised (stacking axis a)",
      stacking_axis(a_stacked) == 0, "got %r" % stacking_axis(a_stacked))

# a diamond-like cell: covalently bonded across every boundary -> no stack
diamond = Structure(
    lattice=np.array([[3.567, 0.0, 0.0], [0.0, 3.567, 0.0], [0.0, 0.0, 3.567]]),
    species=["C"], counts=[2],
    frac_coords=np.array([[0.0, 0.0, 0.0], [0.25, 0.25, 0.25]]),
)
check("a 3D-bonded cell has no stacking axis", stacking_axis(diamond) is None)
check("a 3D-bonded cell is left untouched",
      normalize_stacking_axis(diamond) == (diamond, None))

fixed_b, axis_b = normalize_stacking_axis(b_stacked)
check("a b-stacked cell is relabelled (axis 1 reported)", axis_b == 1,
      "got %r" % axis_b)
check("the relabelled cell now stacks along c",
      stacking_axis(fixed_b) == 2, "got %r" % stacking_axis(fixed_b))
fixed_a, axis_a = normalize_stacking_axis(a_stacked)
check("an a-stacked cell is relabelled (axis 0 reported)", axis_a == 0)
check("the relabelled cell now stacks along c (from a)",
      stacking_axis(fixed_a) == 2)

check("relabelling preserves the cell volume",
      abs(np.linalg.det(fixed_b.lattice) - np.linalg.det(b_stacked.lattice))
      < 1e-9)
check("relabelling preserves the handedness of the cell",
      np.sign(np.linalg.det(fixed_b.lattice))
      == np.sign(np.linalg.det(b_stacked.lattice)))
check("a right-handed input stays right-handed, so no structure is mirrored",
      np.linalg.det(fixed_b.lattice) > 0 and np.linalg.det(fixed_a.lattice) > 0)
cart_before = mono.frac_coords @ mono.lattice
cart_after = fixed_b.frac_coords @ fixed_b.lattice
check("relabelling preserves every Cartesian position",
      float(np.abs(np.sort(cart_after, axis=0)
                   - np.sort(cart_before, axis=0)).max()) < 1e-9)
check("relabelling a c-stacked input is a no-op",
      normalize_stacking_axis(mono) == (mono, None))

# end to end: the engine rejects the b-stacked cell as written, and accepts the
# relabelled one -- which is exactly what the web application now does for the
# user (with a warning naming the axis that was relabelled).
try:
    LayerStackingEngine(b_stacked)
    check("the engine still rejects a stack written along b as-is", False,
          "no exception raised")
except ValueError as exc:
    check("the engine still rejects a stack written along b as-is",
          "2D layered material" in str(exc), "got %r" % str(exc)[:60])
engine_fixed = LayerStackingEngine(fixed_b)
result_b = engine_fixed.build("serrated")
check("the relabelled b-stack builds both layers",
      result_b.natoms_output == 2 * fixed_b.natoms,
      "%d atoms" % result_b.natoms_output)
check("the relabelled stack keeps the reference AA' offset",
      abs(float(result_b.offset_magnitude)
          - float(LayerStackingEngine(mono).build("serrated").offset_magnitude))
      < 1e-6)

# --------------------------------------------------------------------- #
# 3D-framework detection: bonds crossing the c boundary
# --------------------------------------------------------------------- #
print("")
check("a monolayer has no covalent bond crossing c",
      c_direction_bonds(mono) == 0, "got %d" % c_direction_bonds(mono))

# a genuinely 3D input: stack the layer along c and bond the sheets together
# by pulling them within bonding distance
three_d = _permute_axes(mono, (0, 1, 2))  # identity, then edit below
import copy as _copy
lat3 = np.array(three_d.lattice, dtype=float)
lat3[2] = lat3[2] * 0.55          # sheets closer than the vdW gap
frac3 = np.array(three_d.frac_coords, dtype=float)
from cif_io import Structure as _Structure
three_d = _Structure(
    lattice=lat3, species=list(three_d.species),
    counts=list(three_d.counts), frac_coords=frac3, title="3d test")
n3 = c_direction_bonds(three_d)
check("sheets pulled within bonding distance report crossing bonds",
      n3 >= 2, "got %d" % n3)
check("the 3D test input is flagged as not 2D by periodic_axes too",
      periodic_axes(three_d) == [True, True, True],
      "got %r" % (periodic_axes(three_d),))

# --------------------------------------------------------------------- #
print("")
print("%d checks, %d failure(s)" % (_checks, len(_failures)))
for f in _failures:
    print("   FAILED: %s" % f)
sys.exit(1 if _failures else 0)
