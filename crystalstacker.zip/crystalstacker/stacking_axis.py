# -*- coding: utf-8 -*-
"""Locate the layer-stacking direction and relabel the cell so that it is *c*.

Why this module exists
----------------------
The stacking constructions in :mod:`layer_stacking` describe one specific
convention: the layer plane is spanned by **a** and **b**, and the sheets are
stacked along **c**.  That convention is not a property of the material but of
how a particular CIF was written down, and published files disagree about it.
A 2D structure whose cell happens to list the layer normal along **b** is the
same material with the same sheets -- and used to be rejected outright, with a
message about "1D chains or isolated molecules" that described the wrong
problem.

The fix is a pure relabelling.  A layered structure is periodic along two axes
and has no covalent bond across the periodic boundary of the third one; that
third axis *is* the stacking direction.  Detecting it needs no symmetry
analysis and no chemistry beyond which atoms are bonded to which:

* bonds are decided with a covalent-radii criterion
  (``d < r_i + r_j + BOND_TOL``), which reaches dative metal-ligand bonds but
  stays far short of the van der Waals contacts *between* two stacked sheets
  (C...C 3.4 A against a 1.92 A criterion) -- so a stack is not mistaken for a
  3D framework;
* contacts shorter than :data:`MIN_BOND` are ignored: they are two
  half-occupied sites of one disordered atom, or an atom's own image sitting on
  the boundary, not a bond.

Relabelling then permutes the lattice vectors *cyclically* (``abc -> bca`` or
``abc -> cab``), never by a transposition: a transposition would swap two axes
and turn the frame left-handed, i.e. mirror the structure.  The cyclic
permutations preserve the handedness and the atomic geometry exactly -- only
the names of the axes change.

When more (or fewer) than one axis is unbonded the function declines to
guess and returns the structure unchanged: a 3D framework has no stacking
axis, and a 1D chain or a molecular crystal has no *sheet* to stack.  Those
inputs keep being rejected by the engine's two-dimensional check, which can
then say what is actually wrong with them.
"""

from __future__ import annotations

import collections
import itertools
from typing import List, Optional, Tuple

import numpy as np
from scipy.spatial import KDTree

from cif_io import Structure

__all__ = [
    "COVALENT_RADII",
    "BOND_TOL",
    "MIN_BOND",
    "periodic_axes",
    "stacking_axis",
    "normalize_stacking_axis",
]

#: Slack (angstroms) added to the sum of two covalent radii to decide a bond.
BOND_TOL = 0.40
#: Contacts shorter than this are not bonds (duplicate sites, boundary images).
MIN_BOND = 0.50

#: Covalent radii (angstroms) for the elements that occur in framework
#: chemistry, plus a generic fallback.  Values follow the Cordero set used
#: throughout the crystallography literature; the list is deliberately spelled
#: out rather than looked up, because the package must not acquire a
#: chemistry dependency for one distance test.
COVALENT_RADII = {
    "H": 0.31, "He": 0.28, "Li": 1.28, "Be": 0.96, "B": 0.84, "C": 0.76,
    "N": 0.71, "O": 0.66, "F": 0.57, "Ne": 0.58, "Na": 1.66, "Mg": 1.41,
    "Al": 1.21, "Si": 1.11, "P": 1.07, "S": 1.05, "Cl": 1.02, "Ar": 1.06,
    "K": 2.03, "Ca": 1.76, "Sc": 1.70, "Ti": 1.60, "V": 1.53, "Cr": 1.39,
    "Mn": 1.39, "Fe": 1.32, "Co": 1.26, "Ni": 1.24, "Cu": 1.32, "Zn": 1.22,
    "Ga": 1.22, "Ge": 1.20, "As": 1.19, "Se": 1.20, "Br": 1.20, "Kr": 1.16,
    "Rb": 2.20, "Sr": 1.95, "Y": 1.90, "Zr": 1.75, "Nb": 1.64, "Mo": 1.54,
    "Tc": 1.47, "Ru": 1.46, "Rh": 1.42, "Pd": 1.39, "Ag": 1.45, "Cd": 1.44,
    "In": 1.42, "Sn": 1.39, "Sb": 1.39, "Te": 1.38, "I": 1.39, "Xe": 1.40,
    "Cs": 2.44, "Ba": 2.15, "La": 2.07, "Ce": 2.04, "Pr": 2.03, "Nd": 2.01,
    "Pm": 1.99, "Sm": 1.98, "Eu": 1.98, "Gd": 1.96, "Tb": 1.94, "Dy": 1.92,
    "Ho": 1.92, "Er": 1.89, "Tm": 1.90, "Yb": 1.87, "Lu": 1.87, "Hf": 1.75,
    "Ta": 1.70, "W": 1.62, "Re": 1.51, "Os": 1.44, "Ir": 1.41, "Pt": 1.36,
    "Au": 1.36, "Hg": 1.32, "Tl": 1.45, "Pb": 1.46, "Bi": 1.48, "Po": 1.40,
    "Ac": 2.15, "Th": 2.06, "Pa": 2.00, "U": 1.96, "Np": 1.90, "Pu": 1.87,
}
DEFAULT_RADIUS = 1.20


def covalent_radius(symbol: str) -> float:
    """Covalent radius of ``symbol``, with a generic fallback."""
    return COVALENT_RADII.get(str(symbol), DEFAULT_RADIUS)


def periodic_axes(structure: Structure) -> List[bool]:
    """Which of the three axes carry a covalent bond across the boundary.

    The structure is treated as the periodic cell it declares: every atom is
    compared against the atoms of its 26 neighbouring cells, and an axis is
    marked periodic when at least one bond crosses that axis' boundary.
    """
    lattice = np.asarray(structure.lattice, dtype=float)
    frac = np.asarray(structure.frac_coords, dtype=float)
    symbols = [str(s) for s in structure.species_per_atom]
    natoms = len(symbols)
    if natoms == 0:
        return [False, False, False]

    cart = frac @ lattice
    radii = np.array([covalent_radius(s) for s in symbols], dtype=float)

    shifts = np.array(list(itertools.product((-1, 0, 1), repeat=3)), dtype=float)
    cloud = np.vstack([cart + shift @ lattice for shift in shifts])
    cloud_shift = np.repeat(shifts, natoms, axis=0)
    cloud_radius = np.tile(radii, len(shifts))

    cutoff = float(2.0 * radii.max() + BOND_TOL)
    tree = KDTree(cloud)
    neighbours = tree.query_ball_point(cart, cutoff)

    connected = [False, False, False]
    for i, js in enumerate(neighbours):
        if all(connected):
            break
        for j in js:
            shift = cloud_shift[j]
            if not shift.any():
                continue
            distance = float(np.linalg.norm(cloud[j] - cart[i]))
            if distance < MIN_BOND:
                continue
            if distance > radii[i] + cloud_radius[j] + BOND_TOL:
                continue
            for axis in range(3):
                if shift[axis] != 0.0:
                    connected[axis] = True
            if all(connected):
                break
    return connected


def _covalent_bond_graph(structure: Structure):
    """Adjacency list of the covalent-bond graph with periodic shifts.

    Returns ``(adj, natoms, radii, normal)`` where ``adj[i]`` is a list of
    ``(j, shift)`` pairs: atom ``i`` is covalently bonded to atom ``j`` in the
    cell displaced by the integer ``shift`` (minimum-image convention).
    ``normal`` is the unit layer normal (a x b).
    """
    lattice = np.asarray(structure.lattice, dtype=float)
    frac = np.asarray(structure.frac_coords, dtype=float)
    symbols = [str(s) for s in structure.species_per_atom]
    natoms = len(symbols)
    if natoms < 2:
        return [], natoms, np.array([]), None
    cart = frac @ lattice
    radii = np.array([covalent_radius(s) for s in symbols], dtype=float)
    shifts = np.array(list(itertools.product((-1, 0, 1), repeat=3)), dtype=float)
    cloud = np.vstack([cart + shift @ lattice for shift in shifts])
    cutoff = float(2.0 * radii.max() + BOND_TOL)
    tree = KDTree(cloud)
    neighbours = tree.query_ball_point(cart, cutoff)
    adj = [[] for _ in range(natoms)]
    for i, js in enumerate(neighbours):
        for j in js:
            k = int(j % natoms)
            distance = float(np.linalg.norm(cloud[j] - cart[i]))
            if distance < MIN_BOND:
                continue
            if distance > radii[i] + radii[k] + BOND_TOL:
                continue
            shift = tuple(int(x) for x in shifts[j // natoms])
            adj[i].append((k, shift))
    normal = np.cross(lattice[0], lattice[1])
    nrm = np.linalg.norm(normal)
    normal = normal / nrm if nrm > 1e-9 else None
    return adj, natoms, radii, normal


def _cycle_displacements(adj, natoms):
    """All cycle displacements of the periodic bond graph (union-find).

    Every edge carries the cell displacement it crosses.  A cycle whose net
    displacement is non-zero proves the network is periodic along that
    direction: the cycle can be repeated in every cell.  Returns the set of
    net displacements of all detected cycles (each as an (sa, sb, sc) tuple).
    """
    if natoms < 2 or not adj[0]:
        return set()
    parent = list(range(natoms))
    offset = [(0, 0, 0)] * natoms  # displacement from node to its parent
    size = [1] * natoms

    def find(a):
        # Two passes: walk to the root accumulating displacements, then
        # re-point every node on the path straight at the root (path
        # compression).  The offset convention is offset[x] = disp(parent(x)
        # -> x), so the accumulated sum is disp(root -> a) and a compressed
        # node must store disp(root -> node) against its new parent.  Without
        # compression the union chains grow linearly and the edge loop
        # degrades towards quadratic time -- the scaling benchmark's parse
        # stage measured 30 s on a 65k-atom supercell, ~150x the submitted
        # code, with no change in the result.
        root = a
        d = (0, 0, 0)
        while parent[root] != root:
            d = (d[0] + offset[root][0],
                 d[1] + offset[root][1],
                 d[2] + offset[root][2])
            root = parent[root]
        node = a
        disp = d                       # disp(root -> node)
        while parent[node] != node:
            nxt = parent[node]
            step = offset[node]        # disp(parent(node) -> node)
            parent[node] = root
            offset[node] = disp        # disp(root -> node), new parent = root
            disp = (disp[0] - step[0],
                    disp[1] - step[1],
                    disp[2] - step[2])  # disp(root -> nxt)
            node = nxt
        return root, d

    cycles = set()
    for i in range(natoms):
        for k, sh in adj[i]:
            ri, di = find(i)
            rk, dk = find(k)
            net = (di[0] + sh[0] - dk[0],
                   di[1] + sh[1] - dk[1],
                   di[2] + sh[2] - dk[2])
            if ri == rk:
                if net != (0, 0, 0):
                    cycles.add(net)
            elif size[ri] < size[rk]:
                parent[ri] = rk
                offset[ri] = (dk[0] - di[0] - sh[0],
                              dk[1] - di[1] - sh[1],
                              dk[2] - di[2] - sh[2])
                size[rk] += size[ri]
            else:
                # attach the smaller tree under the larger one; the
                # displacement rk -> ri is the inverse of ri -> rk
                parent[rk] = ri
                offset[rk] = (di[0] - dk[0] + sh[0],
                              di[1] - dk[1] + sh[1],
                              di[2] - dk[2] + sh[2])
                size[ri] += size[rk]
    return cycles


def _has_c_periodic_path(adj, natoms, max_shift=None):
    """Is the covalent network periodic along *c*?

    Union-find with offsets over the periodic bond graph: a cycle whose net
    displacement has a non-zero c component proves the network is infinite
    along the stacking direction - the sheets are covalently chained along
    c.  If every cycle nets to zero along c, each connected component is a
    finite-thickness sheet (2D, however thick, buckled or oddly written the
    cell is).

    Returns the number of edges on the shortest c-periodic cycle found
    (0 if none); the edge count is a report, the sign of the c component is
    the criterion.
    """
    cycles = _cycle_displacements(adj, natoms)
    c_cycles = [d for d in cycles if d[2] != 0]
    if not c_cycles:
        return 0
    return max(2, min(abs(d[2]) for d in c_cycles))


def c_direction_bonds(structure: Structure) -> int:
    """Number of covalent bonds that bridge the interlayer gap along *c*.

    A genuine 2D sheet has none: atoms of neighbouring sheets interact only
    through van der Waals gaps (~3.2-3.6 A), far beyond any covalent cutoff.
    A non-zero count therefore means the input is a 3D framework that merely
    *looks* like a layered cell, and :func:`normalize_stacking_axis` will not
    find an unbonded stacking axis for it either.

    Two or more bridging bonds are required to call a structure 3D: a single
    borderline contact can be a measurement artefact in a database CIF.

    The layer normal is taken as a x b, so the input is expected to be
    stacking-axis-normalised already (the web pipeline calls
    :func:`normalize_stacking_axis` first; ``app._load_prepared`` does the
    same).

    The *test* is periodic connectivity, which is representation-independent:
    a structure is 3D exactly when its covalent network closes a loop with a
    net displacement of one cell along c.  This replaced a geometric
    normal-projection test that misfired twice on real data - it counted
    in-plane bonds of oblique cells as bridges (boroxine layers whose c axis
    is tilted), and in-plane bonds of thick sheets whose molecules fill the
    whole cell along c (ReDD-COFFEE structures).  Only when a c-periodic path
    exists does the function fall back to counting candidate bridge bonds for
    the warning text; that count is a report, not the criterion.
    """
    adj, natoms, radii, normal = _covalent_bond_graph(structure)
    if natoms < 2:
        return 0
    path = _has_c_periodic_path(adj, natoms)
    if path == 0:
        return 0
    if normal is None:
        return max(2, path)
    # 3D confirmed: report candidate bridge bonds for the warning text.
    lattice = np.asarray(structure.lattice, dtype=float)
    frac = np.asarray(structure.frac_coords, dtype=float)
    cart = frac @ lattice
    pairs = set()
    for i, js in enumerate(adj):
        for k, sh in js:
            vector = (cart[k] + np.asarray(sh) @ lattice) - cart[i]
            distance = float(np.linalg.norm(vector))
            proj = abs(float(np.dot(vector, normal)))
            if proj >= 0.5 * distance and proj >= 0.8:
                pairs.add((min(i, k), max(i, k)))
    return max(len(pairs), 2)


def stacking_axis(structure: Structure) -> Optional[int]:
    """Index of the stacking axis (the only unbonded one), or ``None``.

    ``None`` means the question is not answered by the geometry: a 3D
    framework is bonded along all three axes, while a 1D chain or a molecular
    crystal is bonded along one or none -- neither has a single sheet normal.
    """
    connected = periodic_axes(structure)
    if connected.count(False) != 1:
        return None
    return connected.index(False)


def _permuted(structure: Structure, order: Tuple[int, int, int]) -> Structure:
    """Same atoms, same geometry, axes renamed according to ``order``."""
    lattice = np.asarray(structure.lattice, dtype=float)[list(order)]
    frac = np.asarray(structure.frac_coords, dtype=float)[:, list(order)]
    return Structure(
        lattice=lattice,
        species=list(structure.species),
        counts=list(structure.counts),
        frac_coords=frac,
        title=structure.title,
        comment=structure.comment,
        expansion_note=structure.expansion_note,
    )


def _dedup_atoms(structure: Structure) -> Structure:
    """Drop atoms that coincide (same element, same fractional position)."""
    frac = np.asarray(structure.frac_coords, dtype=float) % 1.0
    seen = {}
    keep = []
    for i, f in enumerate(frac):
        key = (str(structure.species_per_atom[i]),
               round(float(f[0]), 5), round(float(f[1]), 5), round(float(f[2]), 5))
        if key in seen:
            continue
        seen[key] = i
        keep.append(i)
    if len(keep) == len(frac):
        return structure
    counts = [int(np.sum(np.asarray(structure.species_per_atom)[keep] == sym))
              for sym in structure.species]
    return Structure(
        lattice=np.asarray(structure.lattice, dtype=float),
        species=list(structure.species),
        counts=counts,
        frac_coords=frac[keep],
        title=structure.title,
    )


def contract_setting(structure: Structure) -> Tuple[Structure, Optional[str]]:
    """Rewrite a non-standard hexagonal setting back to the standard one.

    Two representations of a hexagonal sheet defeat the engine's
    in-plane-axis assumptions without changing the material:

    * **orthohexagonal** conventional cells (a, a+2b; gamma = 90 deg) are
      *supercells* of the primitive hexagonal cell: the b periodicity hides
      at half a b' step, so the covalent network is not periodic along b'
      and the sheet looks like two disconnected halves.  The fix is the
      unimodular-free contraction b = (b' - a)/2 followed by de-duplication
      of the coinciding atoms.
    * **gamma = 60 deg** settings (a' = a + b, b' = b) keep the cell area
      but express the slip rules' fractions in a basis where they no longer
      apply; the contraction a = a' - b' restores the standard gamma = 120
      basis without changing the atom count.

    Both contractions are applied only when the result still passes the
    engine's two-dimensional connectivity check and types as hexagonal;
    otherwise the input is returned untouched (the representation is then
    genuinely oblique, not a hexagonal setting).
    """
    from layer_stacking import LayerStackingEngine

    lat = np.asarray(structure.lattice, dtype=float)
    a_len = float(np.linalg.norm(lat[0]))
    b_len = float(np.linalg.norm(lat[1]))
    cosg = float(np.dot(lat[0], lat[1]) / (a_len * b_len))
    gamma = float(np.degrees(np.arccos(max(-1.0, min(1.0, cosg)))))
    candidates = []
    if abs(gamma - 90.0) < 3.0 and abs(b_len / a_len - np.sqrt(3.0)) < 0.05:
        candidates.append(("orthohexagonal conventional cell",
                           np.array([[1.0, 0, 0], [-0.5, 0.5, 0], [0, 0, 1]]),
                           True))
    if abs(gamma - 60.0) < 3.0 and abs(b_len / a_len - 1.0) < 0.05:
        candidates.append(("gamma = 60 deg setting",
                           np.array([[1.0, 0, 0], [-1.0, 1.0, 0], [0, 0, 1]]),
                           False))
    for label, t, dedup in candidates:
        try:
            new_lat = t @ lat
            new_frac = (np.asarray(structure.frac_coords, dtype=float)
                        @ np.linalg.inv(t)) % 1.0
            cand = Structure(lattice=new_lat, species=list(structure.species),
                             counts=list(structure.counts),
                             frac_coords=new_frac, title=structure.title)
            if dedup:
                cand = _dedup_atoms(cand)
            engine = LayerStackingEngine(cand, _setting_fallback=False)
            if engine.lattice_type == "hexagonal":
                return cand, label
        except Exception:  # noqa: BLE001
            continue
    return structure, None


#: Candidate contractions for the brute-force fallback: (label, matrix,
#: de-duplicate?).  ``T`` is applied as ``lattice' = T @ lattice`` with
#: ``frac' = frac @ inv(T)``.
_CONTRACT_CANDIDATES = (
    ("orthohexagonal conventional cell",
     np.array([[1.0, 0, 0], [-0.5, 0.5, 0], [0, 0, 1]]), True),
    ("gamma = 60 deg setting",
     np.array([[1.0, 0, 0], [-1.0, 1.0, 0], [0, 0, 1]]), False),
)


def contract_setting_bruteforce(structure: Structure):
    """Try every known contraction until the engine accepts the result.

    Used as a fallback when the engine's two-dimensional check rejects the
    input as written: a non-standard setting (any lattice type, not only
    hexagonal) is then contracted and the result kept when the engine can
    process it.  Returns ``(structure, note)``; ``(structure, None)`` when no
    candidate helps.
    """
    from layer_stacking import LayerStackingEngine
    lat = np.asarray(structure.lattice, dtype=float)
    for label, t, dedup in _CONTRACT_CANDIDATES:
        try:
            new_lat = t @ lat
            new_frac = (np.asarray(structure.frac_coords, dtype=float)
                        @ np.linalg.inv(t)) % 1.0
            cand = Structure(lattice=new_lat, species=list(structure.species),
                             counts=list(structure.counts),
                             frac_coords=new_frac, title=structure.title)
            if dedup:
                cand = _dedup_atoms(cand)
            LayerStackingEngine(cand, _setting_fallback=False)
            return cand, label
        except Exception:  # noqa: BLE001
            continue
    return structure, None


def normalize_stacking_axis(structure: Structure) -> Tuple[Structure, Optional[int]]:
    """Return ``(structure with the stack along c, relabelled axis index)``.

    ``(structure, None)`` means nothing had to change: the input already
    stacks along **c**, or its geometry does not single out a stacking
    direction at all (3D framework, 1D chain, molecular crystal) -- in the
    latter case the caller should let the engine reject it.

    The two cyclic permutations are the only ones used, so the cell keeps its
    handedness: ``abc -> bca`` when the stack ran along **a**, and
    ``abc -> cab`` when it ran along **b**.  Atomic positions are untouched --
    the Cartesian coordinates of every atom, and every interatomic distance,
    are identical before and after.

    Non-standard hexagonal settings (orthohexagonal conventional cells,
    gamma = 60 deg bases) are first contracted to the standard basis by
    :func:`contract_setting`; the caller can detect this through the
    ``setting_note`` attribute the function leaves on the returned structure.
    """
    contracted, note = contract_setting(structure)
    if note is not None:
        try:
            contracted.setting_note = note
        except Exception:  # noqa: BLE001 - Structure may be immutable-ish
            pass
    structure = contracted
    axis = stacking_axis(structure)
    if axis is None or axis == 2:
        return structure, None
    order = (1, 2, 0) if axis == 0 else (2, 0, 1)
    return _permuted(structure, order), axis
