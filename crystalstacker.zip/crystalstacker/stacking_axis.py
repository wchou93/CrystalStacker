# -*- coding: utf-8 -*-
"""Locate the layer-stacking direction and relabel the cell so that it is *c*.

Why this module exists
----------------------
The stacking constructions in :mod:`layer_stacking` describe one specific
convention: the layer plane is spanned by **a** and **b**, and the sheets are
stacked along **c**.  That convention is not a property of the material but of
how a particular CIF was written down, and published files disagree about it.
A 2D structure whose cell happens to list the layer normal along **b** is the
same material with the same sheets -- and used to be rejected outright, with a
message about "1D chains or isolated molecules" that described the wrong
problem.

The fix is a pure relabelling.  A layered structure is periodic along two axes
and has no covalent bond across the periodic boundary of the third one; that
third axis *is* the stacking direction.  Detecting it needs no symmetry
analysis and no chemistry beyond which atoms are bonded to which:

* bonds are decided with a covalent-radii criterion
  (``d < r_i + r_j + BOND_TOL``), which reaches dative metal-ligand bonds but
  stays far short of the van der Waals contacts *between* two stacked sheets
  (C...C 3.4 A against a 1.92 A criterion) -- so a stack is not mistaken for a
  3D framework;
* contacts shorter than :data:`MIN_BOND` are ignored: they are two
  half-occupied sites of one disordered atom, or an atom's own image sitting on
  the boundary, not a bond.

Relabelling then permutes the lattice vectors *cyclically* (``abc -> bca`` or
``abc -> cab``), never by a transposition: a transposition would swap two axes
and turn the frame left-handed, i.e. mirror the structure.  The cyclic
permutations preserve the handedness and the atomic geometry exactly -- only
the names of the axes change.

When more (or fewer) than one axis is unbonded the function declines to
guess and returns the structure unchanged: a 3D framework has no stacking
axis, and a 1D chain or a molecular crystal has no *sheet* to stack.  Those
inputs keep being rejected by the engine's two-dimensional check, which can
then say what is actually wrong with them.
"""

from __future__ import annotations

import itertools
from typing import List, Optional, Tuple

import numpy as np
from scipy.spatial import KDTree

from cif_io import Structure

__all__ = [
    "COVALENT_RADII",
    "BOND_TOL",
    "MIN_BOND",
    "periodic_axes",
    "stacking_axis",
    "normalize_stacking_axis",
]

#: Slack (angstroms) added to the sum of two covalent radii to decide a bond.
BOND_TOL = 0.40
#: Contacts shorter than this are not bonds (duplicate sites, boundary images).
MIN_BOND = 0.50

#: Covalent radii (angstroms) for the elements that occur in framework
#: chemistry, plus a generic fallback.  Values follow the Cordero set used
#: throughout the crystallography literature; the list is deliberately spelled
#: out rather than looked up, because the package must not acquire a
#: chemistry dependency for one distance test.
COVALENT_RADII = {
    "H": 0.31, "He": 0.28, "Li": 1.28, "Be": 0.96, "B": 0.84, "C": 0.76,
    "N": 0.71, "O": 0.66, "F": 0.57, "Ne": 0.58, "Na": 1.66, "Mg": 1.41,
    "Al": 1.21, "Si": 1.11, "P": 1.07, "S": 1.05, "Cl": 1.02, "Ar": 1.06,
    "K": 2.03, "Ca": 1.76, "Sc": 1.70, "Ti": 1.60, "V": 1.53, "Cr": 1.39,
    "Mn": 1.39, "Fe": 1.32, "Co": 1.26, "Ni": 1.24, "Cu": 1.32, "Zn": 1.22,
    "Ga": 1.22, "Ge": 1.20, "As": 1.19, "Se": 1.20, "Br": 1.20, "Kr": 1.16,
    "Rb": 2.20, "Sr": 1.95, "Y": 1.90, "Zr": 1.75, "Nb": 1.64, "Mo": 1.54,
    "Tc": 1.47, "Ru": 1.46, "Rh": 1.42, "Pd": 1.39, "Ag": 1.45, "Cd": 1.44,
    "In": 1.42, "Sn": 1.39, "Sb": 1.39, "Te": 1.38, "I": 1.39, "Xe": 1.40,
    "Cs": 2.44, "Ba": 2.15, "La": 2.07, "Ce": 2.04, "Pr": 2.03, "Nd": 2.01,
    "Pm": 1.99, "Sm": 1.98, "Eu": 1.98, "Gd": 1.96, "Tb": 1.94, "Dy": 1.92,
    "Ho": 1.92, "Er": 1.89, "Tm": 1.90, "Yb": 1.87, "Lu": 1.87, "Hf": 1.75,
    "Ta": 1.70, "W": 1.62, "Re": 1.51, "Os": 1.44, "Ir": 1.41, "Pt": 1.36,
    "Au": 1.36, "Hg": 1.32, "Tl": 1.45, "Pb": 1.46, "Bi": 1.48, "Po": 1.40,
    "Ac": 2.15, "Th": 2.06, "Pa": 2.00, "U": 1.96, "Np": 1.90, "Pu": 1.87,
}
DEFAULT_RADIUS = 1.20


def covalent_radius(symbol: str) -> float:
    """Covalent radius of ``symbol``, with a generic fallback."""
    return COVALENT_RADII.get(str(symbol), DEFAULT_RADIUS)


def periodic_axes(structure: Structure) -> List[bool]:
    """Which of the three axes carry a covalent bond across the boundary.

    The structure is treated as the periodic cell it declares: every atom is
    compared against the atoms of its 26 neighbouring cells, and an axis is
    marked periodic when at least one bond crosses that axis' boundary.
    """
    lattice = np.asarray(structure.lattice, dtype=float)
    frac = np.asarray(structure.frac_coords, dtype=float)
    symbols = [str(s) for s in structure.species_per_atom]
    natoms = len(symbols)
    if natoms == 0:
        return [False, False, False]

    cart = frac @ lattice
    radii = np.array([covalent_radius(s) for s in symbols], dtype=float)

    shifts = np.array(list(itertools.product((-1, 0, 1), repeat=3)), dtype=float)
    cloud = np.vstack([cart + shift @ lattice for shift in shifts])
    cloud_shift = np.repeat(shifts, natoms, axis=0)
    cloud_radius = np.tile(radii, len(shifts))

    cutoff = float(2.0 * radii.max() + BOND_TOL)
    tree = KDTree(cloud)
    neighbours = tree.query_ball_point(cart, cutoff)

    connected = [False, False, False]
    for i, js in enumerate(neighbours):
        if all(connected):
            break
        for j in js:
            shift = cloud_shift[j]
            if not shift.any():
                continue
            distance = float(np.linalg.norm(cloud[j] - cart[i]))
            if distance < MIN_BOND:
                continue
            if distance > radii[i] + cloud_radius[j] + BOND_TOL:
                continue
            for axis in range(3):
                if shift[axis] != 0.0:
                    connected[axis] = True
            if all(connected):
                break
    return connected


def c_direction_bonds(structure: Structure) -> int:
    """Number of covalent bonds crossing the *c* cell boundary.

    A genuine 2D sheet has none: its atoms interact with the neighbouring
    sheet only through van der Waals gaps (~3.2-3.6 A), far beyond any covalent
    cutoff.  A non-zero count therefore means the input is a 3D framework that
    merely *looks* like a layered cell, and :func:`normalize_stacking_axis`
    will not find an unbonded stacking axis for it either.

    Two or more crossing bonds are required to call a structure 3D: a single
    borderline contact can be a measurement artefact in a database CIF.
    """
    lattice = np.asarray(structure.lattice, dtype=float)
    frac = np.asarray(structure.frac_coords, dtype=float)
    symbols = [str(s) for s in structure.species_per_atom]
    natoms = len(symbols)
    if natoms < 2:
        return 0

    cart = frac @ lattice
    radii = np.array([covalent_radius(s) for s in symbols], dtype=float)

    # only the +/-c images matter
    shifted = np.vstack([cart + lattice[2], cart - lattice[2]])
    tree = KDTree(shifted)

    cutoff = float(2.0 * radii.max() + BOND_TOL)
    neighbours = tree.query_ball_point(cart, cutoff)

    pairs = set()
    for i, js in enumerate(neighbours):
        for j in js:
            distance = float(np.linalg.norm(shifted[j] - cart[i]))
            if distance < MIN_BOND:
                continue
            partner = int(j % natoms)
            tol = radii[i] + radii[partner] + BOND_TOL
            if distance > tol:
                continue
            pairs.add((min(i, partner), max(i, partner)))
    return len(pairs)


def stacking_axis(structure: Structure) -> Optional[int]:
    """Index of the stacking axis (the only unbonded one), or ``None``.

    ``None`` means the question is not answered by the geometry: a 3D
    framework is bonded along all three axes, while a 1D chain or a molecular
    crystal is bonded along one or none -- neither has a single sheet normal.
    """
    connected = periodic_axes(structure)
    if connected.count(False) != 1:
        return None
    return connected.index(False)


def _permuted(structure: Structure, order: Tuple[int, int, int]) -> Structure:
    """Same atoms, same geometry, axes renamed according to ``order``."""
    lattice = np.asarray(structure.lattice, dtype=float)[list(order)]
    frac = np.asarray(structure.frac_coords, dtype=float)[:, list(order)]
    return Structure(
        lattice=lattice,
        species=list(structure.species),
        counts=list(structure.counts),
        frac_coords=frac,
        title=structure.title,
        comment=structure.comment,
        expansion_note=structure.expansion_note,
    )


def normalize_stacking_axis(structure: Structure) -> Tuple[Structure, Optional[int]]:
    """Return ``(structure with the stack along c, relabelled axis index)``.

    ``(structure, None)`` means nothing had to change: the input already
    stacks along **c**, or its geometry does not single out a stacking
    direction at all (3D framework, 1D chain, molecular crystal) -- in the
    latter case the caller should let the engine reject it.

    The two cyclic permutations are the only ones used, so the cell keeps its
    handedness: ``abc -> bca`` when the stack ran along **a**, and
    ``abc -> cab`` when it ran along **b**.  Atomic positions are untouched --
    the Cartesian coordinates of every atom, and every interatomic distance,
    are identical before and after.
    """
    axis = stacking_axis(structure)
    if axis is None or axis == 2:
        return structure, None
    order = (1, 2, 0) if axis == 0 else (2, 0, 1)
    return _permuted(structure, order), axis
