# Case studies

Worked examples covering the four situations that account for almost every
CIF you will meet: an ordinary monolayer, a multilayer input, the rotated mode,
and the boundary cases where the tool has something to warn you about. Every
number quoted here was produced by the current build from the files that ship in
`examples/` and `reference/`.

| Case | Input | What it shows |
|---|---|---|
| [01 — five stacking modes](01-five-stacking-modes.md) | `examples/COF-1_monolayer.cif` | the complete set of stackings from one monolayer, with the offsets and their provenance |
| [02 — multilayer input](02-multilayer-input.md) | `reference/*/serrated-AA.cif`, `staggered-AB.cif` | automatic reduction of a bilayer; extracting the sheet; stray fragments |
| [03 — rotated mode](03-rotated-mode.md) | `examples/CTF-1_monolayer.cif` | layer symmetry, the residual test, and why the warning matters |
| [04 — boundary cases](04-boundary-cases.md) | `examples/ettb-aa.cif`, a b-stacked cell | node-on-node diagnostics, axis relabelling, inputs that are refused |

All examples use the web interface (upload → parameters → download). The same
results are obtained from the command line through the engine API shown at the
end of each case.
