# Case 04 — boundary cases: when the tool warns, and when it refuses

Four situations where a CIF does not fit the comfortable hexagonal/square
monolayer pattern. None of them fails silently: each either produces a result
with a warning that names the problem, or is refused with a message that says
what to change.

## 4.1 A non-primitive cell: node-on-node (example `ettb-aa.cif`)

**Input:** `examples/ettb-aa.cif` — a reported sql framework (Cu₂-paddlewheel +
tetratopic linker), 96 atoms, oblique in-plane cell 18.06 × 21.21 Å, c = 5.91 Å.
The deposited cell is four-fold **non-primitive** (it contains four nodes where
the net's primitive cell has one).

| Mode | Offset source | Result |
|---|---|---|
| serrated (AA′) | `rule - please verify` | \|δ\| = 2.7928 Å from the hexagonal/square rule, flagged because the layer's own symmetry does not confirm the direction |
| staggered (AB) | geometric search | closest approach **0.0001 Å** — node-on-node, warned |

The staggered case is the instructive one. The conventional pore position of
the cell maps node onto node, which means the "staggered" stack is
indistinguishable from an eclipsed one. The tool reports exactly that:

> WARNING: the pore-centre offset maps atoms of layer 2 exactly onto atoms of
> layer 1 (closest approach 0.0001 A). The input cell is probably not primitive;
> enter the true pore position by hand via the in-plane offset.

Two ways forward, both honest:

1. **Enter the measured pore position by hand** (parameter page → *In-plane
   offset → Enter manually*, fractional coordinates of a and b). This is the
   right answer when you know the pore centre from the literature.
2. **Reduce the cell to its primitive form** in the source program and upload
   that. The net, not the cell, defines the pore.

The same mechanism covers the neighbouring case — a conventional pore position
that lands on framework atoms rather than on nodes — where the tool silently
switches to a geometric search of the largest void and tells you it did:

> WARNING: the conventional pore position of the square lattice coincides with
> framework atoms of this cell (closest approach 0.0000 A), so the pore was
> located by a geometric search instead. Verify the result, or enter a measured
> pore position via the in-plane offset.

## 4.2 The stack written along b (or a)

A CIF that lists the layer normal along **b** instead of **c** is the same
material written in a different convention. Uploading it produces:

> The input stacks its layers along the b axis. The cell axes were re-ordered so
> that the stacking direction is c (the layer plane is now a-b); the atomic
> geometry is unchanged.

and then the full set of stacks, with the same offsets and cell parameters as
the c-stacked version of the same structure. Relabelling is cyclic, so the cell
stays right-handed and no atom moves: the check is that the Cartesian
coordinates before and after are identical to 1e-9 Å, which the regression suite
verifies.

**Reproduce it:** permute a monolayer's cell with `abc → bca` (a cyclic
permutation — the old c becomes the new b) and upload it. You can do the same
in the shell:

```python
import numpy as np
from cif_io import read_cif, write_cif, Structure
from stacking_axis import normalize_stacking_axis

s = read_cif("examples/COF-1_monolayer.cif")
order = (1, 2, 0)                       # abc -> bca
swapped = Structure(lattice=s.lattice[list(order)],
                    species=list(s.species), counts=list(s.counts),
                    frac_coords=s.frac_coords[:, list(order)], title="b-stacked")
write_cif(swapped, "_b_stacked.cif")

fixed, axis = normalize_stacking_axis(swapped)
print("stacking axis was", "abc"[axis], "-> now", "abc"[2])
```

## 4.3 A space group without its operations

A CIF that declares a non-P1 space group but lists no symmetry operations cannot
be expanded: reading it as-is would silently return the asymmetric unit — a
structure missing most of its atoms, with nothing to hint at why. The tool
refuses it instead:

> this CIF declares space group 'P 6/m m m' but lists no symmetry operations
> (`_symmetry_equiv_pos_as_xyz` or `_space_group_symop_operation_xyz`), so the
> periodic cell cannot be built and only the asymmetric unit would be read.
> Export the structure with its symmetry operations included, or as an
> explicit P1 cell.

**Fix:** re-export as an explicit P1 cell (every program that writes CIF can),
or add the operation list to the file.

## 4.4 Nothing to stack

A 1D chain, an isolated molecule, a molecular crystal or a 3D framework has no
single sheet normal, so there is no stacking direction to build along. The
two-dimensional check says which axis gave it away:

> This structure does not look like a 2D layered material: its atoms leave an
> empty span of 1.00 of the cell along the b axis. CrystalStacker builds
> interlayer stackings of 2D sheets and cannot process 1D chains or isolated
> molecules. (A 2D structure whose layers stack along a or b rather than c is
> *not* the problem this check reports: relabel its axes with
> stacking_axis.normalize_stacking_axis() before handing it to the engine.)

For a 3D framework the same message appears — correctly: a structure bonded
along all three axes has no interlayer gap to build into.

---

For the full symptom → cause → action table see the manual,
[§7 Troubleshooting](../MANUAL.md#7-troubleshooting).
