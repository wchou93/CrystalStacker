# Case 03 — the rotated mode, and why the warning matters

The rotated mode builds layer 2 by applying a symmetry operation to layer 1
instead of translating it. That only describes a real material when the
operation **is** a symmetry operation of the layer. The tool tests this before
building anything, and says so when it fails.

**Input:** `examples/CTF-1_monolayer.cif` — 42 atoms, hexagonal
a = b = 14.574 Å, c = 3.404 Å.

## 3.1 What the layer's own symmetry allows

The tool first looks for the symmetry axes of the layer (a periodic residual
scan, not a space-group lookup). For CTF-1 it finds exactly one:

```
C2   at 0.00 degrees
```

The list of operations offered by the interface is larger, and that is the
point: the menu shows what can be *requested*, the residual test shows what the
layer can *support*. Choose each operation in turn and read the results table:

| Operation | Residual (Å) | Verdict |
|---|---|---|
| identity (pure translation) | 0.0000 | exact symmetry — no warning |
| transpose (x↔y) | 1.0171 | not a symmetry operation — warned |
| rotation 60° | 1.0178 | not a symmetry operation — warned |
| rotation 120° | 1.6524 | not a symmetry operation — warned |
| rotation 180° | 1.8533 | not a symmetry operation — warned |
| mirror x | 3.8009 | not a symmetry operation — warned |

An operation is flagged above **0.35 Å** — a correct operation about the right
axis leaves a residual of the order of 1e-4 Å, a wrong one is off by an
interatomic distance, so the gap between the two regimes is wide. Only the
identity is exact for CTF-1, which is the honest answer for a layer whose only
in-plane symmetry is a twofold axis along a.

## 3.2 The warning

The flagged results are still written — a hypothetical rotated stacking is a
legitimate thing to ask for — but they are marked, in the results table and on
the page:

> WARNING: the 'rot120' operation is not a symmetry operation of this layer
> (largest residual 1.6524 A). The stack is still written, but the operation
> does not map the layer onto itself — check the result before using it.

and the offset-source column reads *symmetry - not validated* rather than
*symmetry*. Nothing about the run is silent: an unvalidated rotated stack cannot
be mistaken for a validated one when you come back to the folder a month later.

## 3.3 Where the operation is applied

The operation is applied about the **nearest symmetry axis** of the layer, not
about the origin of the cell. The axes of a 2D net need not pass through the
origin of the cell it was written in, so rotating about the origin would move
the layer bodily as well as rotating it. The reported `symmetry_axis` is the
in-plane fractional centre actually used, and the residual above is measured
relative to it.

## 3.4 When to use the rotated mode

* To reproduce a **reported** rotated / twisted stacking: use the operation the
  paper gives, and check that the residual comes back ~0 — if it does, the
  layers really are related by that operation.
* To explore: any operation can be requested, but read the residual column. A
  large residual means you built a structure the layer does not naturally
  adopt; useful as a starting hypothesis, not as a result.

**From the command line**

```python
from cif_io import read_cif
from layer_stacking import LayerStackingEngine

engine = LayerStackingEngine(read_cif("examples/CTF-1_monolayer.cif"))
print(engine.symmetry_axes())            # [(label, direction, angle), ...]
for op in ("identity", "transpose", "rot120"):
    result = engine.build("rotated", symmetry=op)
    print(op, result.symmetry_residual, result.notes[0][:60])
```
