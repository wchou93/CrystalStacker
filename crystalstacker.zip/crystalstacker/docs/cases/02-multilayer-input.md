# Case 02 — multilayer inputs

Most CIFs in a database are **not** monolayers: the deposited structure is the
relaxed bulk cell, with two or more sheets stacked along the stacking axis.
CrystalStacker reduces such an input to its sheet automatically, and the
reduction round-trips — the stack it builds from the reduced sheet reproduces
the cell you started from.

**Input:** `reference/COF-1/serrated-AA.cif` — a DFT-relaxed bilayer of COF-1,
84 atoms, c = 6.8019 Å (the two sheets sit at z = 0 and z = 0.5 of that cell).

## 2.1 Automatic reduction

Upload the bilayer with the three default modes. The parameter page says:

> The input is a bilayer. It was reduced to a single layer before the operation
> was re-applied.

| Step | Atoms | c (Å) |
|---|---|---|
| input cell (bilayer) | 84 | 6.8019 |
| sheet actually stacked | 42 | 3.4009 |
| generated `serrated.cif` | 84 | **6.8019** |
| generated `staggered.cif` | 84 | 6.8019 |

The last two rows are the point: cutting the sheet in half and re-doubling it
returns the original cell exactly. Feeding the same file through again gives the
same numbers — the reduction is idempotent on the reference structures, and the
interlayer spacing is the **layer thickness** (3.4009 Å), not the parent cell's
c (6.8019 Å).

Two other reference bilayers behave identically:

| Input | bilayer → sheet | rebuilt *c* |
|---|---|---|
| `COF-1/serrated-AA.cif` | 84 → 42 atoms, c 6.8019 → 3.4009 | 6.8019 |
| `COF-5/staggered-AB.cif` | 192 → 96 atoms, c 6.8000 → 3.4000 | 6.8000 |
| `CTF-1/serrated-AA.cif` | 84 → 42 atoms, c 6.7624 → 3.3812 | 6.7624 |

## 2.2 Getting the sheet as a file

Tick *Also export the extracted monolayer*. The run writes `monolayer.cif`
beside the stacks: the same 42 atoms, c reset to 3.4009 Å, written as P1 so it
can be handed straight back to the tool (or to any other program) as an input.

This is the recommended workflow when you want to *keep* a monolayer from a
deposited bulk structure: extract it once, then generate any number of
stackings from the clean sheet.

## 2.3 Cells that hold more than two sheets, or a stray fragment

When the z-groups of the input are not two equal sheets, the tool keeps the
**largest** group instead of the first one. That detail matters, because a
database entry often carries something that is not a sheet:

* a guest molecule in the pore, or a half-occupied site, sitting at its own
  fractional z;
* a fragment split across the cell boundary, so it appears twice, at z ≈ 0 and
  z ≈ 1.

The CoRE COF database contains both: cells with 3 stray atoms beside a
123-atom sheet, and cells with 3 beside 156. The gap test calls each cluster a
"layer"; the reduction keeps the 123- or 156-atom sheet, because a three-atom
fragment is not periodic in both in-plane directions and could never be
stacked. The run reports the reduction, so the choice is visible:

> The input holds more than one layer; only the first was used.

**Try it** (this is exactly the input the regression suite uses): take
`examples/COF-1_monolayer.cif` (42 atoms), add three carbon atoms at
`(0.60, 0.60, 0.95)`, `(0.64, 0.60, 0.95)`, `(0.62, 0.63, 0.95)` — clearly
separated in z from the sheet — and upload it. The output `serrated.cif` holds
84 atoms = 2 × 42, i.e. the sheet was stacked and the guest was dropped.

**From the command line**

```python
from cif_io import read_cif
from layer_stacking import LayerStackingEngine, extract_monolayer

bilayer = read_cif("reference/COF-1/serrated-AA.cif")
engine = LayerStackingEngine(bilayer)
print("is a bilayer:", engine.is_bilayer())

sheet = engine.effective_monolayer().structure      # 42 atoms, c = 3.4009
rebuilt = LayerStackingEngine(sheet).build("serrated")
print("rebuilt c:", rebuilt.c_length)               # 6.8019 — the input cell

# and the same sheet as a standalone file, for use as an input elsewhere
extract_monolayer(bilayer, 0)
```
