# Case 01 — five stacking modes from one monolayer

**Input:** `examples/COF-1_monolayer.cif` — 42 atoms, hexagonal cell
a = b = 14.964 Å, c = 3.745 Å, γ = 120°, a single sheet (eclipsed AA).

**Steps**

1. Upload `COF-1_monolayer.cif`.
2. On the parameter page tick all five modes, leave the offset on
   *Determine automatically* and the interlayer spacing empty.
3. *Generate structures*.

**Result** (from the results table and the generated CIF files):

| Mode | Atoms | c (Å) | d (Å) | \|offset\| (Å) | Offset source | Note |
|---|---|---|---|---|---|---|
| eclipsed (AA) | 42 → 42 | 3.745 | 3.7451 | 0.0000 | from input | the monolayer itself |
| inclined | 42 → 42 | 4.119 | 3.7451 | 1.7157 | reference:COF-1 | c tilted by 24.61°; atom count conserved |
| serrated (AA′) | 42 → 84 | 7.490 | 3.7451 | 1.7157 | reference:COF-1 | c doubled |
| staggered (AB) | 42 → 84 | 7.490 | 3.7451 | 8.6395 | symmetry | over the pore centre; clearance 0.6587 Å |
| rotated | 42 → 84 | 7.490 | 3.7451 | 0.0000 | symmetry | transposition of layer 1 |

**What to check in the output**

* *inclined* keeps 42 atoms — the diagonal cell is a shear, not a duplicate. Its
  *c* grew from 3.745 to 4.119 Å; that is the tilt (cos 24.61° = 3.745/4.119) —
  the interlayer spacing is the **z-component** of the new *c*, not its length.
* *serrated* and *staggered* both double the atom count and the *c* axis, and
  differ only in the in-plane offset, so the two are directly comparable: open
  them side by side in VESTA and look down *c*.
* The offset source column is the honesty check. Here COF-1's in-plane cell
  matched the tabulated reference value, so the offset is the measured one
  (1.7157 Å), not a rule-based guess. For a framework that is not in the table
  the column would read `conventional value` or `rule - please verify`, and you
  would supply a measured offset by hand (see the manual, §4.3).

**From the command line**

```python
from cif_io import read_cif
from layer_stacking import LayerStackingEngine, STACKING_MODES

structure = read_cif("examples/COF-1_monolayer.cif")
engine = LayerStackingEngine(structure)
for mode in STACKING_MODES:
    result = engine.build(mode)
    print(mode, result.natoms_output, "atoms, c = %.3f" % result.c_length,
          "offset %.4f from %s" % (result.offset_magnitude, result.offset_source))
```
