# CrystalStacker — User Manual

CrystalStacker builds the classical interlayer stacking arrangements of a
two-dimensional covalent organic framework (COF) — or of any other layered 2D
material — from a single-layer CIF. It is a local web application: you upload
one or more CIF files in a browser, choose the stackings you want, and download
the generated bilayers as CIF files.

This manual covers installation, the input it expects, every parameter, what
the output contains, and what to do when a structure is refused. For worked
examples see [`cases/`](cases/).

---

## 1. Installation

### 1.1 Windows, one-click from source

Double-click `run_webapp.bat`. It finds a suitable Python (3.10+), creates a
local `.venv` next to the sources, installs the dependencies and starts the
server; the browser opens automatically. Nothing is installed system-wide.

### 1.2 Any platform

```bash
python -m venv .venv
# activate it, then:
pip install -r requirements.txt
python app.py
```

Then open `http://127.0.0.1:5000` (a free port is used if 5000 is taken).

### 1.3 Requirements

Python ≥ 3.10, plus `numpy`, `scipy`, `Flask` — see `requirements.txt`.

---

## 2. Input

### 2.1 What to upload

A crystallographic information file (`.cif`) describing **one layer** of the
material — for a COF, the eclipsed AA monolayer is the natural input. One or
several files can be selected at once; all of them are processed with the same
parameters.

The reader accepts what real databases and journals actually contain: values
with standard uncertainties (`14.9640(3)`), quoted strings, `;`-delimited text
fields, `#` comments, `?` / `.` for a missing value, and either fractional or
Cartesian site coordinates.

### 2.2 Symmetry

Symmetry operations listed in the CIF are expanded automatically, so a
`P6/mmm` entry with four unique atoms is read as the full periodic cell. The
expansion is reported rather than done silently:

```
Symmetry-expanded: 42 sites x 8 operations -> 336 atoms
```

A file that *declares* a non-P1 space group but lists **no** operations is
rejected with an explanation — reading it as-is would silently return the
asymmetric unit, i.e. a structure missing most of its atoms:

> this CIF declares space group 'P 6/m m m' but lists no symmetry operations
> (`_symmetry_equiv_pos_as_xyz` or `_space_group_symop_operation_xyz`), so the
> periodic cell cannot be built and only the asymmetric unit would be read.
> Export the structure with its symmetry operations included, or as an
> explicit P1 cell.

Fix such a file by exporting it from the source program as an explicit P1
cell, or by adding the operation list.

### 2.3 Which axis the stack runs along

The stacking constructions assume the layer plane is spanned by **a** and **b**
and the sheets are stacked along **c**. A CIF may just as well write the layer
normal along **a** or **b** — the sheets are the same material, only the axis
names differ.

CrystalStacker detects the stacking direction from the bond topology (the axis
across whose periodic boundary no covalent bond exists) and **relabels the axes
cyclically** so that the stack runs along c. Cyclic relabelling preserves the
handedness of the cell and every Cartesian position exactly — the atoms do not
move. The relabelling is reported:

```
The input stacks its layers along the b axis. The cell axes were re-ordered so
that the stacking direction is c (the layer plane is now a-b); the atomic
geometry is unchanged.
```

Nothing is guessed when the question has no answer: a 3D framework (bonded
along all three axes) and a 1D chain or molecular crystal (no single sheet
normal) are left alone and refused by the two-dimensional check below.

A special case deserves its own paragraph. If the input is covalently bonded
across the **c** boundary, there is no unbonded axis to relabel onto, and the
structure is a 3D framework that merely *looks* like a stacked cell. The tool
does not refuse it — the stack you asked for is still well defined — but it
counts the crossing bonds and warns, so that a silently wrong "monolayer" is
never produced unnoticed:

```
Warning: 16 covalent bonds cross the c cell boundary, so this input is a
covalently bonded 3D framework rather than a van der Waals stacked 2D
material. The result below treats it as a monolayer; use it only if you know
that is what you want.
```

Two or more crossing bonds are required to raise the warning, because a single
borderline contact can be a database artefact. In the 1,262-structure
benchmark of §8 no structure triggered it (every pool entry has an unbonded
axis); the case was found with the Co-TPE-MOF-ABC entry of the accompanying
test set, whose sheets are joined by Co-O coordination bonds (1.87 A).

### 2.4 Multilayer inputs

Inputs that already contain more than one sheet are reduced automatically, and
the reduction is reported:

| Input | What happens | Reported as |
|---|---|---|
| Two sheets, same atoms in each (a bilayer) | the upper sheet is removed | "The input is a bilayer. It was reduced to a single layer…" |
| More than two sheets, or sheets of unequal content | the **largest** z-group is kept | "The input holds more than one layer; only the first was used." |

"In the largest group" matters: a database entry often carries a stray fragment
— a guest molecule in the pore, a half-occupied site — sitting at its own z. The
CoRE COF database contains cells with 3 such atoms beside a 123-atom sheet and
beside a 156-atom sheet. The fragment is a "layer" to the gap test but never the
sheet, so the sheet (the largest group) is the one that is kept.

If you want the extracted sheet **as a file**, tick *Also export the extracted
monolayer* on the parameter page; it is written as `monolayer.cif` with its c
axis reset to a single layer.

### 2.5 What is refused, and why

| Input | Message (abridged) | What to do |
|---|---|---|
| 1D chain, isolated molecule, molecular crystal | "This structure does not look like a 2D layered material: its atoms leave an empty span of 1.00 of the cell along the b axis…" | the tool stacks sheets; use a layered structure |
| 3D framework | same message (no stacking direction exists) | nothing to stack — the structure is already fully connected |
| Not a CIF | "This file does not look like a CIF: no `_cell_length_a` tag was found…" | export as CIF |
| Cell angles inconsistent with the lengths | "cell angles are inconsistent with the lengths…" | fix the cell in the source file |
| Declared space group without operations | see §2.2 | add the operations or export as P1 |

The two-dimensional check asks whether the atoms span the **a** and **b**
directions of the cell they were written in — after any axis relabelling, so a
sheet stacked along b is not mistaken for a chain.

---

## 3. Stacking modes

| Mode | Construction | Atom count of the output |
|---|---|---|
| **eclipsed (AA)** | the input monolayer itself, zero offset | unchanged |
| **inclined** | the *c* vector is tilted by the in-plane offset; fractional coordinates are carried over | unchanged |
| **serrated (AA′)** | *c* doubled; layer 2 = layer 1 translated by the AA′ (slipped-stack) offset | doubled |
| **staggered (AB)** | *c* doubled; layer 2 placed over the pore centre of layer 1 | doubled |
| **rotated** | *c* doubled; layer 2 = layer 1 transformed by a symmetry operation (rotation / mirror / transposition) instead of a translation | doubled |

In the doubled modes the layers sit at z = 0.25 and z = 0.75 of the new cell,
each slab compressed into 0.30 of that cell, leaving a 0.20 interlayer gap — the
gap is deliberately wider than the layer-detection threshold (0.17, §6) so two
sheets are never merged into one.

### 3.1 Interlayer spacing *d*

Optional. Leave it empty to use the *c* length of the input. Any positive value
in Å is accepted; the doubled modes then use 2·*d* as the new *c*, and the
inclined mode uses *d* as the z-component of the tilted *c*.

### 3.2 In-plane offset

*Determine automatically* (default) uses the rules of §4. *Enter manually*
accepts two numbers, read as:

* **fractional** coordinates of **a** and **b** when both are ≤ 1 in magnitude
  (`0.05, 0.03`),
* **Å** otherwise (`1.7, 0.0`) — converted through the in-plane cell.

Supplying a measured offset by hand is the recommended route when the automatic
value comes back flagged as unverified (§4.3), or when your material has a
measured slip that the rules do not cover.

### 3.3 Rotated mode

The operation is chosen from a list (transposition, identity, inversion,
mirrors, 60°–300° rotations). Before a rotation or mirror stack is built the
operation is checked against the layer with a periodic residual test and
applied about the nearest symmetry axis — the symmetry axes of a 2D net need
not pass through the origin of the cell.

The residual is the largest same-species periodic displacement the operation
leaves. For a genuine symmetry operation of the layer it is ~0; for a wrong
operation it is of the order of an interatomic distance. Above 0.35 Å the
operation is flagged and the result is marked *symmetry — not validated*:

> WARNING: the 'rot120' operation is not a symmetry operation of this layer
> (largest residual 1.6524 A). The stack is still written, but the operation
> does not map the layer onto itself — check the result before using it.

The warning is the point: a rotated stack built with an operation the layer does
not have is not the structure you think it is, and the tool will not let that
pass quietly. See `cases/03-rotated-mode.md` for a worked example.

---

## 4. Automatic offsets

### 4.1 AB (staggered) offset

The pore centre of a 2D net is fixed by its **plane group**, so it is taken from
the lattice type: `(2/3, 1/3)` hexagonal, `(1/2, 1/2)` square. For a cell that
is neither — or when the conventional pore position would drive the layers into
each other — the void is located by a geometric search of the largest in-plane
distance to any atom.

Two safeguards are reported rather than hidden:

* **node-on-node** — the offset maps layer 2 exactly onto layer 1 (closest
  approach < 0.01 Å). Typical of a non-primitive cell, where the conventional
  pore vector moves one node onto another. The warning tells you to enter the
  true pore position by hand.
* **pore collision** — the conventional pore position of the lattice coincides
  with framework atoms (closest approach ≈ 0), so the geometric search was used
  instead. Verify the result, or enter a measured pore position.

### 4.2 AA′ (serrated / inclined) offset

The slipped-stack offset is a *chemical* quantity — the second minimum of the
interlayer potential-energy surface — and cannot be derived from an isolated
monolayer. The tool returns the closest derivable value, in this order:

1. a **recognised reference system**, matched on the in-plane cell:
   COF-1 (1.7157 Å at 29.88°), COF-5 (1.5999 Å at 0.00°),
   CTF-1 (1.6705 Å at 30.87°), Pc-PBBA (1.5989 Å at 30.41°);
2. the exact fractional rule — `(2/15, 1/15)` of (a, b) for hexagonal cells
   (|δ| = 0.1155·|a|), `(3/50, 7/200)` for square ones (|δ| = 0.0695·|a|);
3. an empirical magnitude of 1.70 Å when the rule is outside the accepted
   window of 1.00–2.60 Å.

### 4.3 Offset provenance — read this column

Every generated offset reports where it came from, in the results table:

| Source label | Meaning |
|---|---|
| `reference cell (COF-1)` | the measured offset of a recognised reference system |
| `symmetry` | a symmetry-consistent vector (AB pore position of the plane group) |
| `conventional value` | the fractional rule above |
| `rule - please verify` | the rule applies but the layer's own symmetry says the slip direction may follow a symmetry axis instead (the COF-5 case) — treat as unverified |
| `geometric search` | the pore was found numerically (low-symmetry cell or pore collision) |
| `manual` | you entered it |
| `from input` | the eclipsed mode (zero offset) |

`rule - please verify` is not a defect report, it is a request: the AA′
magnitude is chemical, and for a framework whose slip direction is unresolved
from the layer alone the tool would rather say so than return a value that may
be off by a factor of about two (which is exactly what the rule does for COF-5).
In the 1,262-structure benchmark described in §8 this flag appeared for 23.5 % of
the pool — a realistic estimate of how often an independent CIF will need a
measured offset.

---

## 5. Output

### 5.1 Files

| File | Content |
|---|---|
| `eclipsed.cif` | the input layer, unchanged |
| `inclined.cif` | tilted-*c* AA stack (atom count conserved) |
| `serrated.cif` | AA′ stack, *c* doubled |
| `staggered.cif` | AB stack, *c* doubled |
| `rotated-<operation>.cif` | rotated / mirrored stack, *c* doubled |
| `monolayer.cif` | the extracted sheet (only when requested, multilayer inputs) |

Every output is a P1 CIF with an explicit `x, y, z` operation, written with 8
decimals and atom labels grouped by element. The tool never claims a space group
it has not determined, so the files open without ambiguity in VESTA, Mercury,
`pymatgen`, `ASE` or any other viewer.

### 5.2 Batch runs

Several CIFs can be uploaded at once. Each input gets its own folder inside the
ZIP, named after the file:

```
layer_stacking.zip
├── COF-1/inclined.cif, serrated.cif, staggered.cif
├── COF-5/inclined.cif, serrated.cif, staggered.cif
└── ...
```

### 5.3 Where the files go

* from source: `outputs/<run-id>/` next to `app.py`.

Each run has its own `<run-id>` folder, so nothing is overwritten.

---

## 6. How sheets are detected

Sheet separation uses the gap in fractional *z* between consecutive atoms —
which is the whole difficulty, because the threshold has to sit in a narrow
window:

* **above** the largest internal spacing of one sheet. COF-1 is flat but has two
  chemically distinct sub-planes 0.155 apart, and the relaxed CTF-1 layer
  ripples over ~0.08;
* **below** the interlayer gap a stack leaves empty. The constructions here
  leave 0.20 of the cell.

The threshold is therefore 0.17 of the cell (fixed to the cell, not to the
data: a purely relative rule fails because the jitter inside one sheet can
exceed the gap between two sheets, and a fixed Å value fails on a rippled
sheet). Consequence to be aware of: a structure whose *interlayer* gap is
smaller than 0.17 of its *c* axis — a stack written with a very long c — is
reported as a single layer. Supply the interlayer spacing explicitly, or cut the
sheet first, if you hit that case.

A stray fragment (guest molecule, half-occupied site) counts as its own group;
§2.4 explains how the reduction picks the sheet rather than the fragment.

---

## 7. Troubleshooting

| Symptom | Cause | Action |
|---|---|---|
| "does not look like a 2D layered material" | 1D chain, isolated molecule, molecular crystal, or a 3D framework | only layered 2D structures can be stacked |
| "declares space group … but lists no symmetry operations" | CIF carries an asymmetric unit only | add the operations or export as P1 (§2.2) |
| "the input stacks its layers along the b axis" (warning) | axis convention in the file, not a problem | none — the axes were relabelled so the stack is along c |
| "the input is a bilayer…" / "holds more than one layer…" (warning) | multilayer input | none — reduced automatically; tick *extract monolayer* to also get the sheet as a file |
| "the pore-centre offset maps atoms … exactly onto atoms" (warning) | non-primitive cell | enter the true pore position by hand |
| "the conventional pore position … coincides with framework atoms" (warning) | pore site is off the high-symmetry position | verify the result, or enter the measured pore position |
| "the '<op>' operation is not a symmetry operation of this layer" (warning) | the chosen rotation / mirror is not a symmetry of the layer | pick another operation, or accept that the stack is a hypothetical one |
| offset source reads "rule - please verify" | the AA′ rule cannot be confirmed for this framework | supply a measured offset (§3.2) |
| the tool picked a 3-atom fragment instead of the sheet | not possible in the current version: the largest z-group is kept (§2.4) | update to a current build |
| a stack whose interlayer gap is < 0.17 of *c* comes back as one layer | layer-detection window (§6) | cut the sheet first, or set the interlayer spacing explicitly |
| browser does not open | another instance is running, or the port is taken | open the address printed in the console |

---

## 8. Validation and reproducibility

* `test_layer_stacking.py` — 153 checks covering the parser, the rules, the
  builders, the CIF writer, the axis relabelling and the refusals. Every check
  prints `ok` / `FAIL`; the exit status is non-zero on failure.
* `smoke_test_web.py` — end-to-end test driving the real three-step web flow
  with the Werkzeug test client, including a b-stacked input, a stray-fragment
  input and an unvalidated rotated operation.
* `benchmark_scaling.py` — timing benchmark over system sizes.
* `reference/` — the DFT-relaxed reference structures the regression tests
  compare against (COF-1, COF-5, CTF-1, Pc-PBBA; eclipsed, inclined, serrated,
  staggered, plus the rotated reference).

The batch campaign behind the accompanying manuscript processed 1,262 unique
layered structures from the CoRE COF database and CURATED-COFs with **zero CIF
parse failures** and **every structure building all stacking modes** (1,262 /
1,262). Along the way 87 of them were relabelled onto the c stacking axis
(§2.3), 506 were multilayer inputs reduced to their sheet (§2.4), and 23.5 % of
the pool carried the `rule - please verify` flag because the AA′ direction could
not be confirmed from the layer alone (§4.3).

---

## 9. Citing, licence, contact

The source is released under the MIT licence (see `LICENSE`). A manuscript
describing the methodology is in preparation; citation details will be added
upon publication. Authors: Bing Ma, Wei Zhou, Lipiao Bao, Xing Lu.
